# Copyright (C) Intermodulation Products AB, 2018 - All Rights Reserved.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential. Please refer to file LICENSE for details.
"""
Hardware configuration common to all modes of operation.

Detailed information is provided in the documentation for each class:

.. autosummary::
    :nosignatures:

    Hardware
    MultibandMode
    TriggerSource
    AdcMode
    DacMode
    AdcFSample
    DacFSample
"""
import enum
import math
import socket
import struct
from typing import Optional, Tuple
import warnings

import numpy as np

from . import commands as cmd
from .utils import as_flat_list
from .version import version_conductor as VERSION

DEFAULT_ADDR = "192.168.42.50"
DEFAULT_PORT = 7878
RPL_ERR = 0x955F038CD799103F

B_RPL_ERR = struct.pack("<Q", RPL_ERR)


@enum.unique
class TriggerSource(enum.Enum):
    """Select trigger source for starting a pulsed measurement"""

    # 0 is used for stop
    Internal = 1
    """Run immediately"""
    # 2 is used for reset
    Sysref = 4
    """Wait for multi-presto synchronization"""
    DigitalIn1 = 8
    """Wait for high on digital input 1"""
    DigitalIn2 = 16
    """Wait for high on digital input 2"""
    DigitalIn3 = 32
    """Wait for high on digital input 3"""
    DigitalIn4 = 64
    """Wait for high on digital input 4"""


@enum.unique
class MultibandMode(enum.Enum):
    """Configuration options for multiband operation on a tile"""

    SingleBand = 0
    """Each port in tile works independently"""
    DualBand12 = 1
    """Combine ports 1 and 2 into port 1, leave ports 3 and 4 unaffected"""
    DualBand34 = 2
    """Combine ports 3 and 4 into port 3, leave ports 1 and 2 unaffected"""
    DualBandAll = 3
    """Combine ports 1 and 2 into port 1 and ports 3 and 4 into port 3"""
    QuadBand = 4
    """Combine ports 1, 2, 3 and 4 into port 1"""


@enum.unique
class AdcMode(enum.Enum):
    """Configuration for analog-to-digital converters (ADC), i.e. input channels"""

    Direct = cmd.AdcDirect
    """direct mode, i.e. no digital downconversion"""
    Mixed = cmd.AdcMixed
    """IQ mixed mode, i.e. with digital downconversion"""


@enum.unique
class DacMode(enum.Enum):
    """Configuration for digital-to-analog converters (DAC), i.e. output channels"""

    Direct = cmd.DacDirect
    """direct mode, i.e. no digital upconversion"""
    Mixed02 = cmd.DacMixed02
    r"""standard IQ mixed mode, i.e. with digital upconversion. Only valid for sampling rates :math:`f_\mathrm{S} \le 7 \mathrm{GS/s}`"""
    Mixed04 = cmd.DacMixed04
    r"""IQ mixed mode with :math:`f_\mathrm{out} \in [0;f_\mathrm{S}/4] \cup [3f_\mathrm{S}/4;f_\mathrm{S}]`. Only valid on Presto hardware"""
    Mixed42 = cmd.DacMixed42
    r"""IQ mixed mode with :math:`f_\mathrm{out} \in [f_\mathrm{S}/4; 3f_\mathrm{S}/4]`. Only valid on Presto hardware"""


@enum.unique
class AdcFSample(enum.Enum):
    """Sampling rate setting for analog-to-digital converters (ADC), i.e. input channels"""

    G2 = cmd.AdcG2
    r""":math:`f_\mathrm{S} = 2 \mathrm{GS/s}`"""
    G3_2 = cmd.AdcG3_2
    r""":math:`f_\mathrm{S} = 3.2 \mathrm{GS/s}`. Only valid on Vivace hardware"""
    G4 = cmd.AdcG4
    r""":math:`f_\mathrm{S} = 4 \mathrm{GS/s}`. Not valid on 16-channel Presto hardware"""

    def fs(self) -> float:
        return float(self.MSps())

    def fs_nco(self, mode: Optional[AdcMode] = None) -> float:
        return float(self.MSps_nco(mode))

    def nyq(self) -> float:
        return self.fs() / 2.0

    def MSps(self) -> int:
        if self is type(self).G2:
            return 2_000
        elif self is type(self).G3_2:
            return 3_200
        elif self is type(self).G4:
            return 4_000
        else:
            raise NotImplementedError

    def MSps_nco(self, mode: Optional[AdcMode] = None) -> int:
        return self.MSps()

    def to_1st(self, f_MHz: float) -> float:
        fs_MHz = self.fs()
        return _to_1st(f_MHz, fs_MHz)

    def to_1st_nco(self, f_MHz: float, mode: Optional[AdcMode] = None) -> float:
        fs_MHz = self.fs_nco(mode)
        return _to_1st(f_MHz, fs_MHz)

    def round_nco(self, f_MHz: float, mode: Optional[AdcMode] = None) -> float:
        fs_MHz = self.fs_nco(mode)
        n = int(round((f_MHz * 2**48) / fs_MHz))
        return n * fs_MHz / 2**48


@enum.unique
class DacFSample(enum.Enum):
    """Sampling rate setting for digital-to-analog converters (DAC), i.e. output channels"""

    G2 = cmd.DacG2
    r""":math:`f_\mathrm{S} = 2 \mathrm{GS/s}`"""
    G4 = cmd.DacG4
    r""":math:`f_\mathrm{S} = 4 \mathrm{GS/s}`"""
    G6 = cmd.DacG6
    r""":math:`f_\mathrm{S} = 6 \mathrm{GS/s}`. Only valid on Presto hardware"""
    G6_4 = cmd.DacG6_4
    r""":math:`f_\mathrm{S} = 6.4 \mathrm{GS/s}`. Only valid on Vivace hardware"""
    G8 = cmd.DacG8
    r""":math:`f_\mathrm{S} = 8 \mathrm{GS/s}`. Only valid on Presto hardware"""
    G10 = cmd.DacG10
    r""":math:`f_\mathrm{S} = 10 \mathrm{GS/s}`. Only valid on Presto hardware"""

    def fs(self) -> float:
        return float(self.MSps())

    def fs_nco(self, mode: DacMode) -> float:
        return float(self.MSps_nco(mode))

    def nyq(self) -> float:
        return self.fs() / 2.0

    def MSps(self) -> int:
        if self is type(self).G2:
            return 2_000
        elif self is type(self).G4:
            return 4_000
        elif self is type(self).G6:
            return 6_000
        elif self is type(self).G6_4:
            return 6_400
        elif self is type(self).G8:
            return 8_000
        elif self is type(self).G10:
            return 10_000
        else:
            raise NotImplementedError

    def MSps_nco(self, mode: DacMode) -> int:
        if mode is DacMode.Mixed04 or mode is DacMode.Mixed42:
            return self.MSps() // 2
        else:
            return self.MSps()

    def to_1st(self, f_MHz: float) -> float:
        fs_MHz = self.fs()
        return _to_1st(f_MHz, fs_MHz)

    def to_1st_nco(self, f_MHz: float, mode: DacMode) -> float:
        fs_MHz = self.fs_nco(mode)
        return _to_1st(f_MHz, fs_MHz)

    def round_nco(self, f_MHz: float, mode: DacMode) -> float:
        fs_MHz = self.fs_nco(mode)
        n = int(round((f_MHz * 2**48) / fs_MHz))
        return n * fs_MHz / 2**48


def _to_1st(f: float, fs: float) -> float:
    while True:
        if f < -fs / 2:
            f += fs
        elif f > fs / 2:
            f -= fs
        else:
            break
    return f


class Hardware:
    """Interface to the Vivace/Presto hardware.

    This class does not need to be instantiated by the user. It is available as the `hardware` attribute of
    instances of :class:`Lockin <presto.lockin.Lockin>`, :class:`Pulsed <presto.pulsed.Pulsed>` and :class:`Test
    <presto.test.Test>` classes.

    Examples
    --------
    Configure digital IQ mixers:

    >>> from presto.hardware import AdcMode, DacMode
    >>> from presto import lockin
    >>> with lockin.Lockin(adc_mode=AdcMode.Mixed, dac_mode=DacMixed02) as lck:
    >>>     lck.hardware.configure_mixer(
    >>>         freq=3.5e+9,  # 3.5 GHz
    >>>         in_ports=1,
    >>>         out_ports=[1, 2],
    >>>     )
    """

    def __init__(self, address=None, port=None, dry_run=False):
        self.sock = None
        self.dry_run = bool(dry_run)
        self.adc_setup: list[AdcMode] = []
        self.adc_fsample: list[AdcFSample] = []
        self.dac_setup: list[DacMode] = []
        self.dac_fsample: list[DacFSample] = []
        self.board = "zcu216"  # overridden when connected
        # last used range for DC bias: dict[port] = (range_i, range_f)
        self._dc_range: dict[int, tuple[float, float]] = {}

        if not self.dry_run:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                self.sock.setsockopt(socket.SOL_TCP, socket.TCP_NODELAY, 1)
                if address is None:
                    address = DEFAULT_ADDR
                if port is None:
                    port = DEFAULT_PORT
                self.sock.connect((address, port))

                ver = self.get_conductor_version()
                if ver != VERSION:
                    raise RuntimeError(
                        "The version of the software running on the hardware is not compatible with the current API:"
                        f" got {ver}, expected {VERSION}. Have you updated both the API on the computer and the"
                        " software/firmware on the Vivace/Presto hardware?"
                    )
                self.board = self.get_board_name()
            except (Exception, KeyboardInterrupt):
                self.close()
                raise

    def __enter__(self):  # for use with 'with' statement
        return self

    def __exit__(self, exc_type, exc_value, traceback):  # for use with 'with' statement
        self.close()

    def __del__(self):  # get rid of this?
        self.close()

    def close(self):
        """Close the connection to the hardware

        This method is called automatically upon exit from a :ref:`with block <python:with>`
        """
        if self.sock is not None:
            self.sock.close()
            self.sock = None

    def _quit_server(self):
        self.send_command(cmd.Quit)

    def send_command(self, command, *args):
        fmt = "<QQ"
        lng = 16
        args = list(args)  # make a copy
        for ii, arg in enumerate(args):
            if isinstance(arg, (int, np.int64, np.uint64)):
                lng += 8
                fmt += "Q"
                if arg > 0xFFFFFFFFFFFFFFFF or arg < -0x8000000000000000:
                    # don't test for > 0x7fffffffffffffff because we want u64 values to pass
                    raise ValueError(f"{arg} does not fit in 64 bits")
                arg = int(arg) & 0xFFFFFFFFFFFFFFFF
                args[ii] = arg
            elif isinstance(arg, float):
                lng += 8
                fmt += "d"
            elif isinstance(arg, bytes):
                lng += len(arg)
                fmt += f"{len(arg):d}s"
            else:
                raise NotImplementedError(f"don't know what to do with {arg} of type {type(arg)}")
        lst = [lng, command]
        lst.extend(args)
        message = struct.pack(fmt, *lst)
        if not self.dry_run:
            self.sock.sendall(message)

    def _echo(self, val):
        val = int(val)
        self.send_command(cmd.Echo, val)
        reply = self._receive(8)
        return int.from_bytes(reply, byteorder="little", signed=False)

    def _receive(self, N):
        expected = int(N)
        buf = bytearray(expected)
        if not self.dry_run:
            view = memoryview(buf)
            received = 0
            while received < expected:
                remaining = expected - received
                received += self.sock.recv_into(view[received:expected], remaining)
                if buf.startswith(B_RPL_ERR):
                    # raise RuntimeError("the server sent a RPL_ERR value.")
                    self.assert_errors()
        return buf

    def reset(self):
        self.send_command(cmd.Reset)

    def sleep(self, secs, wait=True):
        """Tell the hardware to sleep for `secs` seconds.

        Like :func:`time.sleep`, except the sleep is done on the hardware rather than on the local computer.

        Parameters
        ----------
        secs : float
            duration of sleep in seconds
        wait : bool, optional
            if False, tell the hardware to sleep without waiting for completion. If True (default), block the calling
            thread on the local computer until the hardware is done sleeping
        """
        secs = float(secs)
        self.send_command(cmd.Sleep, secs)

        if wait:
            # send an echo command and wait for answer
            self._echo(42)

    def init_clock(self, ext_ref_clk):
        if ext_ref_clk is None:
            val = 0
        else:
            if isinstance(ext_ref_clk, bool):
                val = 10_000_000 if ext_ref_clk else 0
            else:
                val = int(round(ext_ref_clk))
        self.send_command(cmd.ClockInit, val)

    def set_lmx(self, freq, pwr, ports=None):
        """Configure the clock chip on Presto hardware to use as RF source.

        *The new setting is applied* **immediately**.

        Parameters
        ----------
        freq : float
            frequency in Hz between <~ 10 MHz and 15 GHz
        pwr : int
            power setting in `[0, 47]`
        ports : int or list of int
            valid values are 1 and 2. If None (default), use both.
        """
        if ports is None:
            ports = [1, 2]
        else:
            ports = np.atleast_1d(ports).astype(np.int64)
            if np.any(ports < 1) or np.any(ports > 2):
                raise ValueError("invalid LMX port, valid values are 1 and 2")

        freq = int(round(freq))
        pwr = int(pwr)
        for port in ports:
            channel = port - 1
            self.send_command(cmd.ClockSetLmx, channel, freq, pwr)

    def load_firmware(self, filename):
        self.send_command(cmd.LoadFirmware, filename.encode("utf-8"))

    def init_presto(self):
        self.send_command(cmd.PrestoInit)

    def init_rfdc(self):
        self.send_command(cmd.RfdcInit)

    def sync(self):
        """Manually issue a command to synchronize the NCO phases.

        Can be used after a call to :meth:`configure_mixer` with `sync=False`.

        Examples
        --------
        This code:

        >>> with lockin.Lockin(adc_mode=AdcMode.Mixed, dac_mode=DacMixed02) as lck:
        >>>     lck.hardware.configure_mixer(
        >>>         freq=3.5e+9,  # 3.5 GHz
        >>>         in_ports=1,
        >>>         out_ports=1,
        >>>         sync=False,  # don't sync here...
        >>>     )
        >>>     lck.hardware.sync()  # <-- sync here!

        is equivalent to this code:

        >>> with lockin.Lockin(adc_mode=AdcMode.Mixed, dac_mode=DacMixed02) as lck:
        >>>     lck.hardware.configure_mixer(
        >>>         freq=3.5e+9,  # 3.5 GHz
        >>>         in_ports=1,
        >>>         out_ports=1,
        >>>         sync=True,  # <-- sync here!
        >>>     )
        """
        self.send_command(cmd.RfdcSync)

    def mts(self, target_latency_adc=None, target_latency_dac=None):
        if target_latency_adc is None:
            # use calibrated target latency, encode as -2
            target_latency_adc = 0xFFFFFFFFFFFFFFFE
        elif target_latency_adc == -1:
            # set no target latency, encoded as -1 by XRFdc
            target_latency_adc = 0xFFFFFFFFFFFFFFFF
        elif target_latency_adc > 0:
            target_latency_adc = int(target_latency_adc)
        else:
            raise ValueError(
                f"target_latency_adc must be positive, -1 (no target), or None (calibrated); got {target_latency_adc}"
            )

        if target_latency_dac is None:
            # use calibrated target latency, encode as -2
            target_latency_dac = 0xFFFFFFFFFFFFFFFE
        elif target_latency_dac == -1:
            # set no target latency, encoded as -1 by XRFdc
            target_latency_dac = 0xFFFFFFFFFFFFFFFF
        elif target_latency_dac > 0:
            target_latency_dac = int(target_latency_dac)
        else:
            raise ValueError(
                f"target_latency_dac must be positive, -1 (no target), or None (calibrated); got {target_latency_dac}"
            )

        target_latency_dac = int(target_latency_dac)
        self.send_command(cmd.RfdcMts, target_latency_adc, target_latency_dac)

    def get_var_ver(self):
        self.send_command(cmd.PrestoVarVer)
        reply = self._receive(8)
        variant = int.from_bytes(reply[4:], byteorder="little", signed=False)
        version = int.from_bytes(reply[:4], byteorder="little", signed=False)
        return (variant, version)

    def get_nr_ports(self):
        self.send_command(cmd.NrPorts)
        reply = self._receive(8)
        return int.from_bytes(reply, byteorder="little", signed=False)

    def set_run(self, state, trigger=TriggerSource.Internal):
        value = trigger.value if state else 0
        self.send_command(cmd.PrestoRun, value)

    def _ports_to_mask(self, in_ports, out_ports):
        in_ports = np.atleast_1d(in_ports).astype(np.int64)
        out_ports = np.atleast_1d(out_ports).astype(np.int64)
        mask = 0
        for port in in_ports:
            channel = port - 1
            mask |= 1 << channel
        for port in out_ports:
            channel = port - 1
            mask |= 1 << (channel + 16)
        return mask

    def _blocks_per_tile(self, type_: str) -> int:
        if type_ == "adc":
            if self.board == "zcu216":
                return 4
            elif self.board == "zcu208":
                return 2
            elif self.board == "zcu111":
                return 2
            else:
                raise NotImplementedError(f'unrecognized board "{self.board}"')
        elif type_ == "dac":
            if self.board == "zcu216":
                return 4
            elif self.board == "zcu208":
                return 2
            elif self.board == "zcu111":
                return 4
            else:
                raise NotImplementedError(f'unrecognized board "{self.board}"')
        else:
            raise ValueError(f'`type_` must be "adc" or "dac", got "{type_}"')

    def _nr_ports(self) -> int:
        if self.board == "zcu216":
            return 16
        elif self.board == "zcu208":
            return 8
        elif self.board == "zcu111":
            return 8
        else:
            raise NotImplementedError(f'unrecognized board "{self.board}"')

    def _port_to_tile(self, port: int, type_: str) -> int:
        if port < 1 or port > self._nr_ports():
            raise ValueError(
                f"`port` out of range, must be in [1, {self._nr_ports()}], got {port}"
            )
        blocks_per_tile = self._blocks_per_tile(type_)
        channel = port - 1
        return channel // blocks_per_tile

    def configure_mixer(
        self,
        freq,
        *,
        in_ports=None,
        out_ports=None,
        in_zone=None,
        out_zone=None,
        in_phase=0.0,
        out_phase=0.0,
        sync=True,
        tune=True,
    ):
        r"""Configure the NCO for the digital IQ mixers.

        *The new setting is applied* **immediately**.

        Parameters
        ----------
        freq : float
            frequency of the numerically-controlled oscillator (NCO) in Hz
        in_ports: int or list of int
            configure downconversion for ports in `in_ports`
        out_ports: int or list of int
            configure upconversion for ports in `out_ports`
        in_zone: int, optional
            optimize downconversion mixer for operation in the `in_zone`\ th Nyquist band. If :obj:`None` (default),
            choose appropriate zone automatically
        out_zone: int, optional
            optimize upconversion mixer for operation in the `out_zone`\ th Nyquist band. If :obj:`None` (default),
            choose appropriate zone automatically
        in_phase: float, optional
            phase of the numerically-controlled oscillator (NCO) in radians for each input port
        out_phase: float, optional
            phase of the numerically-controlled oscillator (NCO) in radians for each output port
        sync : bool, optional
            if True (default), issue a :meth:`sync` event to align the phase of the NCO for `in_ports` and `out_ports`.
            When using multiple calls to configure different NCO frequencies on different ports, set `sync=True` only
            on the last call to ensure that all NCO phases align. See Examples section.
        tune : bool, optional
            if True (default), avoid long-term drifts by rounding `freq` so that it is representable exactly by all the
            NCOs in `in_ports` and `out_ports`. If False, `freq` will be programmed as-is into the different NCOs and a
            small frequency mismatch (at most 40 μHz) can occur between different channels, leading to a slow phase
            drift (at most 0.8 deg/min).

        Examples
        --------

        >>> from presto.hardware import AdcMode, DacMode
        >>> from presto import lockin
        >>> with lockin.Lockin(adc_mode=AdcMode.Mixed, dac_mode=DacMixed02) as lck:
        >>>     lck.hardware.configure_mixer(
        >>>         freq=3.5e+9,  # 3.5 GHz
        >>>         in_ports=1,
        >>>         out_ports=1,
        >>>         sync=False,  # sync on last call...
        >>>     )
        >>>     lck.hardware.configure_mixer(
        >>>         freq=3.6e+9,  # 3.6 GHz
        >>>         out_ports=2,
        >>>         sync=False,  # ...not yet...
        >>>     )
        >>>     lck.hardware.configure_mixer(
        >>>         freq=3.7e+9,  # 3.7 GHz
        >>>         out_ports=3,
        >>>         sync=True,  # <-- ...here!
        >>>     )
        """
        if in_ports is None and out_ports is None:
            raise ValueError("At least one of `in_ports` or `out_ports` must be given.")
        if in_ports is None:
            in_ports = np.array([], np.int64)
        else:
            in_ports = np.atleast_1d(in_ports).astype(np.int64)
        if out_ports is None:
            out_ports = np.array([], np.int64)
        else:
            out_ports = np.atleast_1d(out_ports).astype(np.int64)

        _freq_Hz = abs(float(freq))
        if _freq_Hz > 1e10:
            raise ValueError(f"Frequency not supported: got {_freq_Hz} Hz, max is 10 GHz.")
        # NOTE: `freq` in MHz from now on!
        freq = _freq_Hz / 1e6

        if tune:
            nco_fss: list[int] = []  # MHz
            for in_port in in_ports:
                adc_tile = self._port_to_tile(in_port, "adc")
                adc_fsample = self.adc_fsample[adc_tile]
                nco_fss.append(adc_fsample.MSps_nco())
            for out_port in out_ports:
                dac_tile = self._port_to_tile(out_port, "dac")
                dac_fsample = self.dac_fsample[dac_tile]
                dac_setup = self.dac_setup[dac_tile]
                nco_fss.append(dac_fsample.MSps_nco(dac_setup))
            lcm = _lcm(*nco_fss)  # MHz
            increment = int(round((freq * 2**48) / lcm))
            freq = increment * lcm / 2**48

        for in_port in in_ports:
            adc_tile = self._port_to_tile(in_port, "adc")
            adc_fsample = self.adc_fsample[adc_tile]
            adc_nyq = adc_fsample.nyq()

            if in_zone is None:
                in_zone = 1 + int(freq // adc_nyq)
            else:
                in_zone = int(in_zone)
            self._set_nyquist(in_port, [], in_zone)

            if tune:
                freq_1st = adc_fsample.to_1st_nco(freq)
                freq_round = adc_fsample.round_nco(freq_1st)
                freq_nco = freq_round
                if in_zone % 2 == 0:  # even zone
                    freq_nco = -freq_nco
            else:
                freq_nco = freq

            if in_zone % 2 == 1:  # odd zone
                self._set_nco(in_port, [], -freq_nco, in_phase, sync=False)
            else:  # even zone
                self._set_nco(in_port, [], +freq_nco, in_phase, sync=False)

        for out_port in out_ports:
            dac_tile = self._port_to_tile(out_port, "dac")
            dac_fsample = self.dac_fsample[dac_tile]
            dac_setup = self.dac_setup[dac_tile]
            dac_nyq = dac_fsample.nyq()

            if out_zone is None:
                out_zone = 1 + int(freq // dac_nyq)
            else:
                out_zone = int(out_zone)
            self._set_nyquist([], out_port, out_zone)

            if tune:
                freq_1st = dac_fsample.to_1st_nco(freq, dac_setup)
                freq_round = dac_fsample.round_nco(freq_1st, dac_setup)
                freq_nco = freq_round
                if out_zone % 2 == 0:  # even zone
                    freq_nco = -freq_nco
            else:
                freq_nco = freq

            if out_zone % 2 == 1:  # odd zone
                self._set_nco([], out_port, +freq_nco, out_phase, sync=False)
            else:  # even zone
                self._set_nco([], out_port, -freq_nco, out_phase, sync=False)

            warn = False
            range_str = ""
            setup_str = ""
            if dac_setup == DacMode.Mixed02:
                setup_str = "DacMixed02"
                range_str = f"[0,{0.9e-3*dac_nyq:.1f}]\u222a[{1.1e-3*dac_nyq:.1f},{1.9e-3*dac_nyq:.1f}] GHz"
                if 0.9 * dac_nyq < freq < 1.1 * dac_nyq or freq > 1.9 * dac_nyq:
                    warn = True
            elif dac_setup == DacMode.Mixed04:
                setup_str = "DacMixed04"
                range_str = f"[0,{0.4e-3*dac_nyq:.1f}]\u222a[{1.6e-3*dac_nyq:.1f},{1.9e-3*dac_nyq:.1f}] GHz"
                if 0.4 * dac_nyq < freq < 1.6 * dac_nyq or freq > 1.9 * dac_nyq:
                    warn = True
            elif dac_setup == DacMode.Mixed42:
                setup_str = "DacMixed42"
                range_str = f"[{0.6e-3*dac_nyq:.1f},{0.9e-3*dac_nyq:.1f}]\u222a[{1.1e-3*dac_nyq:.1f},{1.4e-3*dac_nyq:.1f}] GHz"
                if (
                    freq < 0.6 * dac_nyq
                    or 0.9 * dac_nyq < freq < 1.1 * dac_nyq
                    or freq > 1.4 * dac_nyq
                ):
                    warn = True
            if warn:
                warnings.warn(
                    message=f"Frequency {freq} is outside recommended range {range_str} for current DAC setup {setup_str} on tile {dac_tile}",
                    category=UserWarning,
                    stacklevel=2,
                )

        if sync:
            self.sync()

    def _set_nco(self, in_ports, out_ports, freq_MHz, phase, sync=True):
        in_ports = np.atleast_1d(in_ports).astype(np.int64)
        out_ports = np.atleast_1d(out_ports).astype(np.int64)
        freq = float(freq_MHz) * 1e6
        phase = float(phase)

        for port in np.r_[in_ports, out_ports + 16]:
            self.send_command(cmd.RfdcSetNCO, port - 1, freq, phase)
        if sync:
            self.sync()

    def _set_nyquist(self, in_ports, out_ports, zone):
        in_ports = np.atleast_1d(in_ports).astype(np.int64)
        out_ports = np.atleast_1d(out_ports).astype(np.int64)
        zone = int(zone)
        zone = 2 - (zone % 2)  # 1 for odd and 2 for even zones

        for port in np.r_[in_ports, out_ports + 16]:
            self.send_command(cmd.RfdcNyquist, port - 1, zone)

    def set_cal_freeze(self, freeze):
        """Freeze/unfreeze the background calibration of the input ports (ADC)

        *The new setting is applied* **immediately**.

        Parameters
        ----------
        freeze : bool
            set to True to freeze (stop) the background calibration; set to False to unfreeze
        """
        value = 1 if freeze else 0
        self.send_command(cmd.RfdcCalFreeze, value)

    def save_cal_coeff(self):
        """Save the current coefficients for the background calibration of the input ports (ADC)"""
        self.send_command(cmd.RfdcCalSave)

    def restore_cal_coeff(self):
        """Restore previously saved coefficients for the background calibration of the input ports (ADC)

        *The new setting is applied* **immediately**.
        """
        self.send_command(cmd.RfdcCalRestore)

    def get_input_multiband(self, tile: int) -> MultibandMode:
        """Return current multiband configuration on an input tile.

        Parameters
        ----------
        tile
            group of ports affected by multiband, valid values are in `[0, 3]`.
            See :ref:`adv tile` for port grouping.

        See also
        --------
        set_input_multiband
        """
        if tile not in [0, 1, 2, 3]:
            raise ValueError(f"`tile` must be in `[0, 3]`, got {tile}")
        self.send_command(
            cmd.RfdcGetInMultiBand,
            tile,
        )
        reply = self._receive(8)
        mode_value = int.from_bytes(reply, byteorder="little", signed=False)
        return MultibandMode(mode_value)

    def set_input_multiband(self, tile: int, mode: MultibandMode):
        """Configure multiband operation on an input tile.

        Parameters
        ----------
        tile
            group of ports affected by multiband, valid values are in `[0, 3]`.
            See :ref:`adv tile` for port grouping.
        mode
            multiband configuration to enable

        See also
        --------
        get_input_multiband
        """
        if tile not in [0, 1, 2, 3]:
            raise ValueError(f"`tile` must be in `[0, 3]`, got {tile}")
        self.send_command(
            cmd.RfdcSetInMultiBand,
            tile,
            mode.value,
        )

    def get_output_multiband(self, tile: int) -> MultibandMode:
        """Return current multiband configuration on an output tile.

        Parameters
        ----------
        tile
            group of ports affected by multiband, valid values are in `[0, 3]`.
            See :ref:`adv tile` for port grouping.

        Notes
        -----
        Output multiband is currently not supported on Presto-8 hardware.

        See also
        --------
        set_output_multiband
        """
        if tile not in [0, 1, 2, 3]:
            raise ValueError(f"`tile` must be in `[0, 3]`, got {tile}")
        self.send_command(
            cmd.RfdcGetOutMultiBand,
            tile,
        )
        reply = self._receive(8)
        mode_value = int.from_bytes(reply, byteorder="little", signed=False)
        return MultibandMode(mode_value)

    def set_output_multiband(self, tile: int, mode: MultibandMode):
        """Configure multiband operation on an output tile.

        Parameters
        ----------
        tile
            group of ports affected by multiband, valid values are in `[0, 3]`.
            See :ref:`adv tile` for port grouping.
        mode
            multiband configuration to enable

        Notes
        -----
        Output multiband is currently not supported on Presto-8 hardware.

        See also
        --------
        get_output_multiband
        """
        if tile not in [0, 1, 2, 3]:
            raise ValueError(f"`tile` must be in `[0, 3]`, got {tile}")
        self.send_command(
            cmd.RfdcSetOutMultiBand,
            tile,
            mode.value,
        )

    def set_inv_sinc(self, ports, mode):
        """Enable/disable the inverse-sinc FIR filter on the output ports (DAC)

        *The new setting is applied* **immediately**.

        Parameters
        ----------
        ports : int or list of int
        mode : int
            which FIR filter to use: 0 disables correction; 1 for operation in 1st Nyquist zone; 2 for operation in 2nd
            Nyquist zone (only on Presto hardware)

        Notes
        -----
        Using the inverse-sinc correction can improve gain flatness over frequency, but can cause clipping of the
        output when used at full-scale amplitude. To avoid clipping, it is recommended to not drive above -3.5 dBFS
        when `mode=1`, and -1.0 dBFS when `mode=2`.
        """
        ports = np.atleast_1d(ports).astype(np.int64)
        mode = int(mode)
        for port in ports:
            channel = port - 1
            self.send_command(cmd.RfdcSetInvSinc, channel, mode)

    def set_dac_current(self, ports, current_ua):
        """Set the full-scale current of the output ports (DAC)

        Results in changing the analog range of the output.

        *The new setting is applied* **immediately**.

        Parameters
        ----------
        ports : int or list of int
        current_ua : int
            full-scale current in μA, see Notes for valid values

        Notes
        -----
        On Vivace hardware, valid values for `current_ua` are `20_000` (20 mA) and `32_000` (32 mA).
        On Presto hardware, valid values range from `2_250` (2.25 mA) to `40_500` (40.5 mA) in
        steps of 43.75 μA.
        """
        ports = np.atleast_1d(ports).astype(np.int64)
        current_ua = int(current_ua)
        for port in ports:
            channel = port - 1
            self.send_command(cmd.RfdcSetDacCurrent, channel, current_ua)

    def set_adc_attenuation(self, ports, attenuation):
        """Set the attenuation of the input ports (ADC)

        Results in changing the analog range of the input. Only on Presto hardware.

        *The new setting is applied* **immediately**.

        Parameters
        ----------
        ports : int or list of int
        attenuation : float
            attenuation in dB, valid values are between 0.0 and 27.0 in steps of 1.0 dB
        """
        ports = np.atleast_1d(ports).astype(np.int64)
        attenuation = float(attenuation)
        for port in ports:
            channel = port - 1
            self.send_command(cmd.RfdcSetDSA, channel, attenuation)

    def default_config(self):
        self.send_command(cmd.RfdcDefaultConfig)

    def blank_output(self, ports, state):
        """Disable the output port(s). Has no effect on the DC bias.

        *The new setting is applied* **immediately**.

        Parameters
        ----------
        ports : int or list of int
            Output ports to enable/disable
        state : bool
            When :obj:`True`, disable the RF output.
        """
        ports = np.atleast_1d(ports).astype(np.int64)
        val = 1 if state else 0
        for port in ports:
            channel = port - 1
            self.send_command(cmd.TestBlank, channel, val)

    @staticmethod
    def validate_config(adc_setup, adc_fsample, dac_setup, dac_fsample, force_config=False):
        adc_setup = as_flat_list(adc_setup)
        adc_fsample = as_flat_list(adc_fsample)
        dac_setup = as_flat_list(dac_setup)
        dac_fsample = as_flat_list(dac_fsample)

        for elem in adc_setup:
            if not isinstance(elem, AdcMode):
                raise TypeError(f"`adc_mode` must be of type `AdcMode`, got {type(elem)}")
        for elem in adc_fsample:
            if not isinstance(elem, AdcFSample):
                raise TypeError(f"`adc_fsample` must be of type `AdcFSample`, got {type(elem)}")
        for elem in dac_setup:
            if not isinstance(elem, DacMode):
                raise TypeError(f"`dac_mode` must be of type `DacMode`, got {type(elem)}")
        for elem in dac_fsample:
            if not isinstance(elem, DacFSample):
                raise TypeError(f"`dac_fsample` must be of type `DacFSample`, got {type(elem)}")

        if len(adc_setup) == 1:
            adc_setup = np.tile(adc_setup, 4)
        elif len(adc_setup) != 4:
            raise ValueError(
                "expected either 1 (all tile the same) or 4 (one per tile) values for `adc_mode`"
            )

        if len(adc_fsample) == 1:
            adc_fsample = np.tile(adc_fsample, 4)
        elif len(adc_fsample) != 4:
            raise ValueError(
                "expected either 1 (all tile the same) or 4 (one per tile) values for `adc_fsample`"
            )

        if len(dac_setup) == 1:
            dac_setup = np.tile(dac_setup, 4)
        elif len(dac_setup) != 4:
            raise ValueError(
                "expected either 1 (all tile the same) or 4 (one per tile) values for `dac_mode`"
            )

        if len(dac_fsample) == 1:
            dac_fsample = np.tile(dac_fsample, 4)
        elif len(dac_fsample) != 4:
            raise ValueError(
                "expected either 1 (all tile the same) or 4 (one per tile) values for `dac_fsample`"
            )

        if not force_config:
            for (setup, fsample) in zip(dac_setup, dac_fsample):
                if (fsample.value > cmd.DacG6_4) and (setup.value < cmd.DacMixed04):
                    raise ValueError(
                        f"{setup} is not recommended for sampling rates above 7 GS/s, "
                        f"use {DacMode.Mixed04} or {DacMode.Mixed42} instead. "
                        "To ignore this error and preceed anyway, pass the argument `force_config=True`."
                    )

        return (adc_setup, adc_fsample, dac_setup, dac_fsample)

    def setup_config(self, adc_setup, adc_fsample, dac_setup, dac_fsample, force_config=False):
        (
            self.adc_setup,
            self.adc_fsample,
            self.dac_setup,
            self.dac_fsample,
        ) = self.validate_config(
            adc_setup, adc_fsample, dac_setup, dac_fsample, force_config=force_config
        )

        adc_mask = 0
        dac_mask = 0

        for i in range(4):
            adc_mask |= self.adc_setup[i].value << (i * 16)
            adc_mask |= self.adc_fsample[i].value << (i * 16 + 8)
            dac_mask |= self.dac_setup[i].value << (i * 16)
            dac_mask |= self.dac_fsample[i].value << (i * 16 + 8)

        self.send_command(cmd.RfdcConfig, adc_mask, dac_mask)

    def start_dma(self, dma_idx, nr_bytes, nr_cycles=1, high_mem=False):
        dma_idx = int(dma_idx)
        nr_bytes = int(nr_bytes)
        nr_cycles = int(nr_cycles)
        high_mem = 1 if high_mem else 0
        self.send_command(cmd.PrestoDmaStart, dma_idx, nr_bytes, nr_cycles, high_mem)

    def wait_for_dma(self, dma_idx, wait=True):
        dma_idx = int(dma_idx)
        self.send_command(cmd.PrestoDmaWait, dma_idx)

        if wait:
            # send an echo command and wait for answer
            self._echo(42)

    def stop_dma(self, dma_idx):
        dma_idx = int(dma_idx)
        self.send_command(cmd.PrestoDmaStop, dma_idx)

    def get_dma_status(self, dma_idx):
        dma_idx = int(dma_idx)
        self.send_command(cmd.PrestoDmaStatus, dma_idx)
        reply = self._receive(8)
        status = int.from_bytes(reply, byteorder="little", signed=False)
        done = (status >> 63) & 1 == 1
        error = (status >> 62) & 1 == 1
        nr_bytes = status & 0xFFFFFFFFFFFF
        return (done, error, nr_bytes)

    def get_dma_data(self, nr_bytes, high_mem=False):
        nr_bytes = int(nr_bytes)
        high_mem = 1 if high_mem else 0
        self.send_command(cmd.PrestoDmaGet, nr_bytes, high_mem)

        reply = self._receive(nr_bytes)
        return reply

    def get_ocm_status(self):
        self.send_command(cmd.PrestoOcmError)
        reply = self._receive(8)
        status = int.from_bytes(reply, byteorder="little", signed=False)
        done = bool(status & 1)
        error = status & ~1
        return (done, error)

    def _write_raw_dc(self, word):
        word = int(word)
        self.send_command(cmd.PrestoDcRaw, word)

    def _read_dc_word(self):
        self.send_command(cmd.PrestoDcReadback)
        reply = self._receive(8)
        word = int.from_bytes(reply, byteorder="little", signed=False)
        return word

    def _get_marker_in(self):
        self.send_command(cmd.PrestoMarkerIn)
        reply = self._receive(8)
        return int.from_bytes(reply, byteorder="little", signed=False)

    def _set_marker_out(self, mask):
        mask = int(mask)
        self.send_command(cmd.PrestoMarkerOut, mask)

    def set_dc_bias(self, bias, port, range_i=None):
        """Set a DC bias on the output ports.

        *The new setting is applied* **immediately**.

        Parameters
        ----------
        bias : float
            DC bias value. Must be within the selected range.

        port : int or array_like
            Output port, if :obj:`None` set DC bias for all ports.
            See Notes for valid ports.

        range_i : int, optional
            Range setting for DC bias DAC. On Vivace hardware this setting is ignored and the selected range is always
            ±1.0 FS. On Presto hardware, the default behavior is to auto-select an appropriate range based on the value
            of `bias`. See Notes for other available options.

        Raises
        ------
        ValueError
            If `bias` or `port` are outside valid range.

        Notes
        -----
        On Vivace hardware, the DC bias is applied to the RF output ports by means of a internal bias tees; as such,
        valid values for `port` are in the interval `[1,8]`. On Presto hardware, DC bias is provided from the dedicated
        DC output ports on the front panel; valid values for `port` are then in the interval `[1,16]` regardless of the
        available number of RF outputs.

        On Presto hardware, there are 5 available range settings:

        =========  ============
        `range_i`  Analog range
        =========  ============
        0          0V — 3.33V
        1          0V — 6.67V
        2          ±3.33V
        3          ±6.67V
        4          ±10.0V
        =========  ============

        When selecting `range_i=None` (default), the API will choose the smallest bipolar range (2, 3 or 4) such that
        `bias` is at most 90% of the range.

        Examples
        --------

        >>> from presto import lockin
        >>> with lockin.Lockin() as lck:
        >>>     lck.hardware.set_dc_bias(
        >>>         bias=5.0,  # 5V
        >>>         port=[5, 6, 7, 8],  # update 4 ports simultaneously
        >>>         range_i=None,  # auto-select `range_i=3`, i.e. ±6.67V
        >>>     )
        >>>     lck.hardware.set_dc_bias(
        >>>         bias=-2.0,  # -2V
        >>>         port=1,
        >>>         range_i=4,  # manually select `range_i=4`, i.e. ±10.0V
        >>>     )

        See also
        --------
        get_dc_bias
        """
        bias = float(bias)
        if self.board == "zcu111":
            max_bias = 1.0
            min_bias = -max_bias
            range_i = 0xFF
            max_port = 8
        else:
            max_port = 16
            if range_i is None:
                if abs(bias) <= 3.0:
                    max_bias = 10.0 / 3.0
                    range_i = 2
                elif abs(bias) <= 6.0:
                    max_bias = 20.0 / 3.0
                    range_i = 3
                else:
                    max_bias = 10.0
                    range_i = 4
                min_bias = -max_bias
            else:
                if range_i == 0:
                    max_bias = 10.0 / 3.0
                    min_bias = 0.0
                elif range_i == 1:
                    max_bias = 20.0 / 3.0
                    min_bias = 0.0
                elif range_i == 2:
                    max_bias = 10.0 / 3.0
                    min_bias = -max_bias
                elif range_i == 3:
                    max_bias = 20.0 / 3.0
                    min_bias = -max_bias
                elif range_i == 4:
                    max_bias = 10.0
                    min_bias = -max_bias
                else:
                    raise ValueError(f"unknown range setting: {range_i}")

        if bias > max_bias or bias < min_bias:
            raise ValueError(f"`bias` must be in [{min_bias:.2f},{max_bias:.2f}], got {bias}")
        bias /= max_bias
        if abs(bias) > 1.0:
            # just in case
            raise ValueError(f"normalized |`bias`| must be <= 1.0, got {bias}")

        if port is None:
            port = np.arange(1, max_port + 1)
        else:
            port = np.atleast_1d(port).astype(np.int64)
            if np.any(port) < 1 or np.any(port) > max_port:
                raise ValueError(f"port must be in [1, {max_port}]")

        channel_mask = 0
        for p in port:
            ch = int(p - 1)
            channel_mask |= 1 << ch
            self._dc_range[p] = (min_bias, max_bias)
        self.send_command(cmd.PrestoDcBias, channel_mask, bias, range_i)

    def get_dc_bias(self, port: int) -> float:
        """Get the DC bias programmed on the output ports.

        Parameters
        ----------
        port
            Output port. See Notes in :meth:`set_dc_bias` for valid ports.

        Returns
        -------
        float
            The DC bias currently set in units of volts (V) on Presto hardware,
            or in full-scale units (FS) on Vivace hardware.

        Raises
        ------
        ValueError
            If `port` is outside valid range.

        See also
        --------
        set_dc_bias
        """
        port = int(port)
        if self.board == "zcu111":
            max_port = 8
        else:
            max_port = 16
        if port < 1 or port > max_port:
            raise ValueError(f"port must be in [1, {max_port}]")
        channel = port - 1
        self.send_command(cmd.PrestoDcGetBias, channel)
        reply = self._receive(8)
        (bias,) = struct.unpack("<d", reply)
        return bias

    def last_dc_range(self, port: int) -> Tuple[float, float]:
        return self._dc_range[port]  # raise KeyError if key `port` is missing

    def get_conductor_version(self):
        self.send_command(cmd.Version)
        reply = self._receive(8)
        nr_bytes = int.from_bytes(reply, byteorder="little", signed=False)
        reply = self._receive(nr_bytes)
        return reply.decode("utf-8")

    def get_rpu_version(self):
        self.send_command(cmd.PrestoRpuVer)
        reply = self._receive(8)
        nr_bytes = int.from_bytes(reply, byteorder="little", signed=False)
        reply = self._receive(nr_bytes)
        return reply.decode("utf-8")

    def get_errors(self):
        """Get error messages, if any, from the hardware.

        Returns
        -------
        list of str

        See also
        --------
        print_errors
        assert_errors
        """
        self._echo(42)  # send echo command to wait for all errors to propagate
        self.send_command(cmd.ErrorList)
        errors = []
        nr_bytes = int.from_bytes(self._receive(8), byteorder="little", signed=False)
        while nr_bytes > 0:
            errors.append(self._receive(nr_bytes).decode("utf-8"))
            nr_bytes = int.from_bytes(self._receive(8), byteorder="little", signed=False)
        return errors

    def format_errors(self) -> str:
        """Format error messages from the hardware, ready for printing.

        Returns
        -------
        str
            a formatted string containing the errors, or an empty string.

        See also
        --------
        get_errors
        assert_errors
        """
        errors = self.get_errors()
        msg = []
        if errors:
            msg.append(f"\x1B[1;31m{' SERVER ERROR ':-^80}\x1B[0m")
            for err in errors:
                msg.append(err)
            msg.append(f"\x1B[1;31m{'':-^80}\x1B[0m")
            msg_txt = "\n".join(msg)
            return msg_txt
        else:
            return ""

    def assert_errors(self):
        """Print errors from the hardware and raise an exception if there were any.

        Raises
        -------
        RuntimeError

        See also
        --------
        get_errors
        print_errors
        """
        errors = self.format_errors()
        if errors:
            raise RuntimeError(f"got errors from the hardware, check the log below.\n{errors:s}")

    def get_board_name(self):
        self.send_command(cmd.WhichBoard)
        reply = self._receive(8)
        nr_bytes = int.from_bytes(reply, byteorder="little", signed=False)
        reply = self._receive(nr_bytes)
        return reply.decode("utf-8")

    def get_intr_status(self):
        self.send_command(cmd.IntrStatus)
        reply = self._receive(8)
        return int.from_bytes(reply, byteorder="little", signed=False)

    def check_adc_intr_status(self):
        status = self.get_intr_status()
        if status > 0:
            print_adc_intr_status(status, all_=False, color=True)

    def intr_clr(self):
        self.send_command(cmd.IntrClr)


def print_adc_intr_status(status, all_=True, color=False):
    start = "\x1B[1;33m" if color else ""
    stop = "\x1B[0m" if color else ""
    for i in range(16):
        elem = (status >> (4 * i)) & 0xF
        if all_ or elem > 0:
            print(f"{start}Input {i+1:2d} out of range: {elem:04b}{stop}")


def _lcm(*integers):
    nargs = len(integers)
    if nargs == 0:
        return 1
    res = integers[0]
    if nargs == 1:
        return abs(res)
    for i in range(1, nargs):
        x = integers[i]
        if res == 0:
            continue
        res = _long_lcm(res, x)
    return res


def _long_lcm(a: int, b: int) -> int:
    if a == 0 or b == 0:
        return 0
    g = math.gcd(a, b)
    f = a // g
    m = f * b
    return abs(m)
