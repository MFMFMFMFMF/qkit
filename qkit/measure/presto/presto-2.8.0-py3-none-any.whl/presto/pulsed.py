# Copyright (C) Intermodulation Products AB, 2018 - All Rights Reserved.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential. Please refer to file LICENSE for details.
"""
Pulse-based experiment design and measurement.

Detailed information is provided in the documentation for each class.

.. autosummary::
    :nosignatures:

    Pulsed
    LongDrive
    Event
    Template
    Match
    MeasurementHandle
    MeasurementStatus
    # NextFreq
    # NextScale
    # ResetPhase
    # SelFreq
    # SelScale
    # Store

**Converter modes** (re-exported from :mod:`hardware <presto.hardware>` module):

  .. autoclass:: AdcMode

     See :class:`AdcMode <presto.hardware.AdcMode>` for full documentation

  .. autoclass:: DacMode

     See :class:`DacMode <presto.hardware.DacMode>` for full documentation

**Converter sampling rates** (re-exported from :mod:`hardware <presto.hardware>` module):

  .. autoclass:: AdcFSample

     See :class:`AdcFSample <presto.hardware.AdcFSample>` for full documentation

  .. autoclass:: DacFSample

     See :class:`DacFSample <presto.hardware.DacFSample>` for full documentation

**Module constants**:

  .. autodata:: MAX_LUT_ENTRIES
  .. autodata:: MAX_COMMANDS
  .. autodata:: MAX_STORE_LEN
  .. autodata:: MAX_TEMPLATE_LEN
  .. autodata:: MAX_THRESHOLD
"""
from __future__ import annotations

import copy
from datetime import datetime, timedelta
import enum
import functools
import math
import threading
import time
from typing import List, Optional
import warnings
import weakref
from weakref import ReferenceType

import numpy as np

from . import commands as cmd
from .hardware import AdcFSample, AdcMode, DacFSample, DacMode, Hardware, TriggerSource
from .utils import as_flat_list, format_sec, eprint_error
from .version import version_fpga, version_rpu

VARIANT = 6

OUT_TMPL_PER_CH = 16
OUT_TMPL_PER_GRP = OUT_TMPL_PER_CH // 2
NR_MATCH_GROUPS = 16
MATCH_TMPL_PER_GRP = 8
NR_COMPARATORS = NR_MATCH_GROUPS * MATCH_TMPL_PER_GRP // 2
NR_CONDITIONERS = 8
GRPS_PER_CMD = 4
MAX_LUT_ENTRIES = 512
"""maximum length of frequency/phase and scale look-up tables"""
MAX_STORE_LEN = 1_048_576
"""maximum number of samples in a contiguous acquisition window (:meth:`store <Pulsed.store>`)"""
SMPLS_PER_CLK = 4
MAX_TEMPLATE_LEN = 2048 - SMPLS_PER_CLK
"""maximum number of data points in a single template slot in direct mode. See also :meth:`get_max_template_len <Pulsed.get_max_template_len>`"""
AVERAGING_RATE = 1e9  # S/s

# Internally we use int64 to represent the threshold and the match results
# In the API we use float64 scaled by 32767**2 so that a perfect match
# of a full-scale cosine gives 0.5 * T
_THRESHOLD_SCALE = 32767**2
# In Theory MAX_THRESHOLD could be (2**63 - 1) / _THRESHOLD_SCALE
# but we only have 52 bit precision, so we lose 11 bits
MAX_THRESHOLD = (2**63 - 2**11 - 1) / _THRESHOLD_SCALE
"""maximum threshold/result value for a template :meth:`match <Pulsed.match>`"""
_STORE_TO_MATCH_LATENCY = -3
"""clock cycles beween a store and a match event"""
_DLY_DIG_OUT = 0
"""int: delay `DigitalOut` event to align with `Template` output"""

_DMA_MIN = 16 * 4  # bytes
_DMA_MUL = 16  # bytes
_DMA_MAX = 2_147_483_648  # 2 GBytes
_BYTES_PER_STORE_SAMPLE = 4  # when averaging
_BYTES_PER_MATCH = 8
# _CMD_BUF_LEN = 4608
_OCM_BASE_ADDR = 0xFFFC_0000
_OCM_END_ADDR = 0xFFFE_A000
_OCM_SIZE = _OCM_END_ADDR - _OCM_BASE_ADDR
_OCM_LEN_U64 = _OCM_SIZE // 8
MAX_COMMANDS = (
    _OCM_LEN_U64 - 32
) // 2  # commands (2x64bit words per command, 32 words used for parameters)
"""maximum number of commands (trigger events) in an experiment sequence"""
_WRAPPING_TIME = 1 << 18  # clk cycles

_CHANNEL_MATCH_BASE = 16  # encode match command in 16 <= channel < 32
_CHANNEL_DIGOUT = 32  # encode store command as channel 32
_CHANNEL_STORE = 33  # encode store command as channel 33
_NR_FIFOS = 34  # <-- the last command channel + 1
_MAX_TIME_OCM_CLK = 0x0000FFFFFFFFFFFF  # OCM stores time as 48 bits

_T_ZERO = datetime.fromtimestamp(0)

_ADD_DUMMIES = True


def no_after_run(meth):
    @functools.wraps(meth)
    def wrapper(self, *args, **kwargs):
        if self._status is not MeasurementStatus.IDLE:
            raise RuntimeError(f"method `{meth.__name__}` can't be called after `run`")
        return meth(self, *args, **kwargs)

    return wrapper


class Pulsed:
    def __init__(
        self,
        ext_ref_clk=False,
        force_reload=False,
        dry_run=False,
        address=None,
        port=None,
        adc_mode=AdcMode.Direct,
        adc_fsample=AdcFSample.G2,
        dac_mode=DacMode.Direct,
        dac_fsample=DacFSample.G4,
        force_config=False,
    ):
        r"""Use the hardware in pulsed mode.

        Warnings
        --------
        Create only one instance at a time. Use each instance for only one measurement. This class is designed to be
        instantiated with Python's :ref:`with statement <python:with>`, see Examples section.

        Parameters
        ----------
        ext_ref_clk : optional
            if :obj:`None` or :obj:`False` use internal reference clock; if :obj:`True` use external reference clock
            (10 MHz); if :class:`float` or :class:`int` use external reference clock at `ext_ref_clk` Hz
        force_reload : bool, optional
            if :obj:`True` re-configure clock and reload firmware even if there's no change from the previous settings.
        dry_run : bool, optional
            if :obj:`False` don't connect to hardware, for testing only.
        address : str, optional
            IP address or hostname of the hardware. If :obj:`None`, use factory default `"192.168.42.50"`.
        port : int, optional
            port number of the server running on the hardware. If :obj:`None`, use factory default `7878`.
        adc_mode : hardware.AdcMode or list, optional
            configure the inputs to sample in direct mode (default), or to use the digital mixers for downconversion.
            See Notes.
        adc_fsample : hardware.AdcFSample or list, optional
            configure the inputs sampling rate (default 2 GS/s). See Notes.
        dac_mode : hardware.DacMode or list, optional
            configure the outputs to work in direct mode (default), to use the digital mixers for upconversion. See
            Notes.
        dac_fsample : hardware.DacFSample or list, optional
            configure the outputs sampling rate (default 4 GS/s). See Notes.
        force_config : bool, optional
            if :obj:`True` skip checks on `DacMode`\ s not recommended for high DAC sampling rates.

        Raises
        ------
        ValueError
            if `adc_mode` or `dac_mode` are not valid :ref:`converter modes`;
            if `adc_fsample` or `dac_fsample` are not valid :ref:`converter rates`.

        Notes
        -----
        In all the Examples, it is assumed that the imports ``import numpy as np`` and ``from presto import pulsed``
        have been performed, and that this class has been instantiated in the form ``pls = pulsed.Pulsed()``, or,
        **much much better**, using the ``with pulsed.Pulsed() as pls`` construct as below.

        For valid values of `adc_mode` and `dac_mode`, see :ref:`converter modes`. For valid values of `adc_fsample`
        and `dac_fsample`, see :ref:`converter rates`. For advanced configuration, e.g. different converter rates on
        different ports, see :ref:`adv tile`.

        Examples
        --------
        Output a 2 ns pulse on output port 1 every 100 :math:`\mu`\s, and sample 1 :math:`\mu`\s of data from input
        port 1. Repeat 10 times, average 10_000 times.

        >>> from presto import pulsed
        >>> with pulsed.Pulsed() as pls:
        >>>     pls.set_store_ports(1)
        >>>     pls.set_store_duration(1e-6)
        >>>     pulse = pls.setup_template(
        >>>         output_port=1,
        >>>         group=0,
        >>>         template=np.ones(4),
        >>>     )
        >>>     pls.output_pulse(0.0, pulse)
        >>>     pls.store(0.0)
        >>>     pls.run(
        >>>         period=100e-6,
        >>>         repeat_count=10,
        >>>         num_averages=10_000,
        >>>         print_time=True,
        >>>     )
        >>>     t_arr, data = pls.get_store_data()
        connecting to 192.168.42.50 port 7878
        Expected runtime: 10.0s
        Total time: 10.2s
        Transfering data: 3.0ms
        """
        self._status = MeasurementStatus.IDLE
        self._time_start = _T_ZERO
        self._time_end = _T_ZERO

        self.dry_run = bool(dry_run)
        adc_mode, adc_fsample, dac_mode, dac_fsample = Hardware.validate_config(
            adc_mode, adc_fsample, dac_mode, dac_fsample, force_config=force_config
        )

        # this API only supports either all tiles Direct or all tiles Mixed
        # ADC and DAC can be different
        # different types of Mixed (DAC gen3) are fine
        if 0 < np.sum(adc_mode == AdcMode.Direct) < 4:
            raise NotImplementedError(
                "all ADC tiles must be configured with the same mode (all Direct or all Mixed)"
            )
        if 0 < np.sum(dac_mode == DacMode.Direct) < 4:
            raise NotImplementedError(
                "all DAC tiles must be configured with the same mode type (all Direct or any combination of MixedXX)"
            )
        self.adc_direct = adc_mode[0] == AdcMode.Direct
        self.dac_direct = dac_mode[0] == DacMode.Direct

        if 0 < np.sum(adc_fsample == AdcFSample.G3_2) < 4:
            raise NotImplementedError(
                "if adc_fsample=AdcFSample.G3_2 on one tile, then all ADC tiles must use it"
            )
        if 0 < np.sum(dac_fsample == DacFSample.G6_4) < 4:
            raise NotImplementedError(
                "if dac_fsample=DacFSample.G6_4 on one tile, then all DAC tiles must use it"
            )
        if (AdcFSample.G3_2 in adc_fsample) ^ (DacFSample.G6_4 in dac_fsample):
            raise NotImplementedError(
                "adc_fsample=AdcFSample.G3_2 and dac_fsample=DacFSample.G6_4 must be used together"
            )

        self.CLK_T = 2.5e-9 if adc_fsample[0] == AdcFSample.G3_2 else 2e-9
        self.CLK_F = 400e6 if adc_fsample[0] == AdcFSample.G3_2 else 500e6

        self._nr_ports = 16  # changed below after connecting to the hardware
        self.thread = None
        self.hardware = Hardware(address, port, dry_run)
        """Hardware: interface to hardware features common to all modes of operation"""

        try:
            if not self.dry_run:
                if force_reload:
                    self.hardware.reset()
                self.hardware.init_clock(ext_ref_clk)
                self.hardware.load_firmware(f"presto_{VARIANT:d}_{version_fpga:d}.bin")
                self.hardware.init_presto()
                self.hardware.init_rfdc()

                var, ver = self.hardware.get_var_ver()
                if var != VARIANT:
                    raise RuntimeError(
                        f"The loaded firmware variant {var} does not match the expected {VARIANT}."
                        " This should not happen, please contact Intermodulation Products for support."
                    )
                if ver != version_fpga:
                    raise RuntimeError(
                        "The version of the PL firmware running on the hardware is not compatible with the current API"
                        f": got {ver}, expected {version_fpga}. Have you updated both the API on the computer and the"
                        " software/firmware on the Vivace/Presto hardware?"
                    )
                ver = self.hardware.get_rpu_version()
                if ver != version_rpu:
                    raise RuntimeError(
                        "The version of the RPU firmware running on the hardware is not compatible with the current"
                        f" API: got {ver}, expected {version_rpu}. Have you updated both the API on the computer and"
                        " the software/firmware on the Vivace/Presto hardware?"
                    )
                self._nr_ports = self.hardware.get_nr_ports()

            # set user-requested configuration for the data converters
            self.hardware.setup_config(
                adc_mode, adc_fsample, dac_mode, dac_fsample, force_config=force_config
            )
            # then we do MTS to align the FIFOs
            self.hardware.mts()
            self.hardware.assert_errors()

            self.hardware.intr_clr()
            _ = self.hardware.get_intr_status()  # the first after MTS is polluted
            self.hardware.check_adc_intr_status()
        except (Exception, KeyboardInterrupt):
            self.close()
            raise

        self.store_channels: List[int] = []
        self.store_len = 0
        self.saves = []
        self.used_templates: List[List[int]] = [[0] * 2 for _ in range(self._nr_ports)]
        self.used_match_templates = np.zeros((NR_MATCH_GROUPS, MATCH_TMPL_PER_GRP), dtype=bool)
        self.templates: List[List[Optional[np.ndarray]]] = [
            [None] * OUT_TMPL_PER_CH for _ in range(self._nr_ports)
        ]
        self.match_templates: List[List[Optional[np.ndarray]]] = [
            [None] * MATCH_TMPL_PER_GRP for _ in range(NR_MATCH_GROUPS)
        ]
        self.scale_luts: List[List[Optional[np.ndarray]]] = [
            [None] * 2 for _ in range(self._nr_ports)
        ]
        self.freq_luts: List[List[Optional[np.ndarray]]] = [
            [None] * 2 for _ in range(self._nr_ports)
        ]
        self.phase_i_luts: List[List[Optional[np.ndarray]]] = [
            [None] * 2 for _ in range(self._nr_ports)
        ]
        self.phase_q_luts: List[List[Optional[np.ndarray]]] = [
            [None] * 2 for _ in range(self._nr_ports)
        ]
        self._scale_shifts: List[List[int]] = [[0] * 2 for _ in range(self._nr_ports)]
        self._freq_shifts: List[List[int]] = [[0] * 2 for _ in range(self._nr_ports)]
        self._scale_axis: List[List[int]] = [[0] * 2 for _ in range(self._nr_ports)]
        self._freq_axis: List[List[int]] = [[0] * 2 for _ in range(self._nr_ports)]
        self.modulate: List[int] = [0] * self._nr_ports
        self.seq = []

        self._match_data = None
        self._match_tags = None
        self._avg_data = None
        self._avg_t_arr = None

        self.used_conditioners = 0
        self.comparator_thresholds = [
            0
        ] * NR_COMPARATORS  # 64bit thresholds, one per comparator (compare_constant)
        self.comparator_crossport = 0  # 64bits, one bit per comparator (compare_iq)
        self.conditional = (
            0  # 256 bits, one bit per output template, 1 means conditional (default_mask)
        )
        self.conditional_false = (
            0  # 256 bits, one bit per output template, 1 means inverted (invert_condition)
        )
        self.conditioner_inputs = [0] * NR_CONDITIONERS
        # one bit per comparator (64bit words), 1 means don't use this comparison (condition_mask)
        self.conditioner_outputs = [0] * NR_CONDITIONERS
        # 256bit words, 1 bit per output template, 1 means control this output template (user_mask)

    def __enter__(self):  # for use with 'with' statement
        return self

    def __exit__(self, *_):  # for use with 'with' statement
        self.close()

    def __del__(self):  # get rid of this?
        self.close()

    def time_to_clk(self, t):
        """Convert `t` to an integer number of clock cycles, raising an :class:`Exception` if rounding is needed.

        Parameters
        ----------
        t : float
            time in seconds

        Returns
        -------
        int
            number of clock cycles

        Raises
        ------
        ValueError
            if `t` is not an integer multiple of :meth:`get_clk_T`;
            if `t` is negative.

        See also
        --------
        round_time
        get_clk_T
        """
        t = float(t)
        c = int(round(t * self.CLK_F))
        if c < 0:
            raise ValueError("`t` must be nonnegative")
        if abs(c * self.CLK_T - t) > self.CLK_T / 100:
            raise ValueError(f"`t`={t} is not a multiple of the clock period {self.CLK_T}")
        return c

    def round_time(self, t):
        """Round `t` to a multiple of the clock period.

        Parameters
        ----------
        t : float
            time in seconds

        Returns
        -------
        float
            the closest multiple of :meth:`get_clk_T` to `t`

        See also
        --------
        get_clk_T
        time_to_clk
        """
        t = float(t)
        c = int(round(t * self.CLK_F))
        return c * self.CLK_T

    def close(self):
        """Gracely disconnect from the hardware.

        Call this method if the class was instantiated without a :ref:`with statement <python:with>`. This method is
        called automatically when exiting a ``with`` block and before the object is destructed.
        """
        if self.hardware is not None:
            self.hardware.close()

    def get_clk_f(self):
        """Frequency of the programmable logic clock in Hz.

        Returns
        -------
        float
        """
        return self.CLK_F

    def get_clk_T(self):
        """Period of the programmable logic clock in seconds.

        Returns
        -------
        float
        """
        return self.CLK_T

    def get_fs(self, which):
        """Get sampling frequency for `which` converter in Hz.

        Parameters
        ----------
        which : str
            "adc" for input and "dac" for output.

        Raises
        ------
        ValueError
            if `which` is unknown.
        """
        if which == "adc":
            if self.adc_direct:
                return 4 * self.get_clk_f()
            else:
                return 2 * self.get_clk_f()
        elif which == "dac":
            if self.dac_direct:
                return 4 * self.get_clk_f()
            else:
                return 2 * self.get_clk_f()
        else:
            raise ValueError(f"`which` can be 'adc' or 'dac', got {which}")

    def get_nr_ports(self):
        """The number of available input/output ports in the hardware.

        Returns
        -------
        int
        """
        return self._nr_ports

    def get_max_template_len(self) -> int:
        """Maximum number of data points in a single template slot.

        Equal to :const:`MAX_TEMPLATE_LEN` when in direct mode (`dac_mode` is :class:`DacMode.Direct <DacMode>`), and
        half of it when using digital upconversion (`dac_mode` is one of :class:`DacMode.Mixedxx <DacMode>`).
        """
        if self.dac_direct:
            return MAX_TEMPLATE_LEN
        else:
            return MAX_TEMPLATE_LEN // 2

    @no_after_run
    def set_store_ports(self, input_ports):
        r"""Set input port(s) for all store events.

        Parameters
        ----------
        input_ports : int or list of int
            Valid ports are in the interval `[1,` :meth:`get_nr_ports`\ `]`.

        Raises
        ------
        ValueError
            If any of `input_ports` is out of `[1,` :meth:`get_nr_ports`\ `]`.
        """
        input_ports = np.atleast_1d(input_ports).astype(np.int64)
        if input_ports.min() < 1 or input_ports.max() > self._nr_ports:
            raise ValueError(f"valid input ports are 1-{self._nr_ports}")
        self.store_channels = input_ports - 1

    @no_after_run
    def set_store_duration(self, T):
        """Set the duration of all data acquisition events.

        Parameters
        ----------
        T : float
            Duration in seconds. Must be a multiple of :meth:`get_clk_T`

        Raises
        ------
        ValueError
            if `T` is not a multiple of :meth:`get_clk_T`;
            if a store `T` on all channels configured with :meth:`set_store_ports` results in an acquisition window
            with more than :const:`MAX_STORE_LEN` samples.
        RuntimeError
            If :meth:`set_store_ports` was never called before.

        See also
        --------
        set_store_ports
        store
        """
        if len(self.store_channels) == 0:
            raise RuntimeError("did you forget to run set_store_ports?")
        clk_cyc = self.time_to_clk(T)
        nr_samples = clk_cyc * SMPLS_PER_CLK
        nr_channels = len(self.store_channels)
        tot_samples = nr_channels * nr_samples
        if tot_samples > MAX_STORE_LEN or tot_samples <= 0:
            raise ValueError(
                f"`T` = {1e9 * T:.0f} ns on {nr_channels} channels results in {tot_samples} samples, "
                f"but maximum is {MAX_STORE_LEN}"
            )
        self.store_len = nr_samples

    @no_after_run
    def store(self, at_time):
        """Program hardware to acquire data from the input ports at given time.

        Parameters
        ----------
        at_time : float
            at what time in seconds the acquisition should start. Must be a multiple of :meth:`get_clk_T`

        Raises
        ------
        ValueError
            if `at_time` is not a multiple of :meth:`get_clk_T`;
        RuntimeError
            if the store duration and the input ports have not been set up.

        Notes
        -----
        The input ports and the duration of the acquisition are set up separately, see See also section below.

        See also
        --------
        set_store_duration
        set_store_ports
        """
        if self.store_len == 0:
            raise RuntimeError("did you forget to run set_store_duration?")
        if len(self.store_channels) == 0:
            raise RuntimeError("did you forget to run set_store_ports?")

        duration = self.store_len // SMPLS_PER_CLK
        time_clk = self.time_to_clk(at_time)
        for channel in self.store_channels:
            store = Store(channel=channel, duration=duration)
            self.seq.append([time_clk, store])
            self.saves.append((channel, self.store_len))

    @no_after_run
    def setup_scale_lut(self, output_ports, group, scales, axis=-1):
        r"""Setup look-up table for global output scale.

        Parameters
        ----------
        output_ports : int or array_like
            Valid ports are in the interval `[1,` :meth:`get_nr_ports`\ `]`.
        group: int
            Valid groups are in the interval `[0, 1]`.
        scales : float or array_like
            Output scale in ratio of full scale.
        axis : int, optional
            For multi-dimensional parameter sweeps, axis over which :meth:`next_scale` should
            increment scale index. If not given, the last (innermost) axis is used.
            Multi-dimensional parameter sweeps are *experimental* and the API might be fine tuned in a future release.

        Raises
        ------
        ValueError
            If any of `output_ports` is out of `[1,` :meth:`get_nr_ports`\ `]`;
            if any of `scales` is out of `[-1.0, +1.0]`;
            if the LUT is longer than :const:`MAX_LUT_ENTRIES`;
            if `group` is out of `[0, 1]`.

        See also
        --------
        next_scale
        select_scale
        """
        output_ports = np.atleast_1d(output_ports).astype(np.int64)
        if output_ports.min() < 1 or output_ports.max() > self._nr_ports:
            raise ValueError(f"valid output ports are 1-{self._nr_ports}")

        group = int(group)
        if group not in range(2):
            raise ValueError("valid groups are 0-1")

        scales = np.atleast_1d(scales).astype(np.float64)
        if len(scales) > MAX_LUT_ENTRIES:
            raise ValueError(f"`scales` can contain at most {MAX_LUT_ENTRIES:d} elements")
        if np.any(np.abs(scales) > 1.0):
            raise ValueError("scale must be in [-1.0; +1.0]")

        for port in output_ports:
            channel = port - 1
            self.scale_luts[channel][group] = scales.copy()
            self._scale_axis[channel][group] = axis

    @no_after_run
    def setup_freq_lut(self, output_ports, group, frequencies, phases, phases_q=None, axis=-1):
        r"""Setup look-up table for frequency generator.

        Parameters
        ----------
        output_ports : int or array_like
            valid ports are in the interval `[1,` :meth:`get_nr_ports`\ `]`.
        group: int
            valid groups are in the interval `[0, 1]`.
        frequencies : float or array_like
            frequency/ies in Hz for the generator.
        phases : float or array_like
            phase(s) in radians for the generator. Must be same length as `frequencies`. When `dac_mode` is not
            :class:`DacMode.Direct <DacMode>`, this are the phases of the I quadrature to the upconversion digital
            mixer.
        phases_q : float or array_like
            phase(s) in radians for Q quadrature to the upconversion digital mixer. Must be specified if and only if
            `dac_mode` is not :class:`DacMode.Direct <DacMode>`.
        axis : int, optional
            For multi-dimensional parameter sweeps, axis over which :meth:`next_frequency` should
            increment frequency/phase index. If not given, the last (innermost) axis is used.
            Multi-dimensional parameter sweeps are *experimental* and the API might be fine tuned in a future release.

        Raises
        ------
        ValueError
            If any of `output_ports` is out of `[1,` :meth:`get_nr_ports`\ `]`;
            if any of `frequencies` is out of `[0.0,` :meth:`get_fs("dac") <get_fs>`\ `)`;
            if `group` is out of `[0, 1]`;
            if `phases` doesn't have the same shape as `frequencies`;
            if the LUTs are longer than :const:`MAX_LUT_ENTRIES`;
            if `phases_q` is specified when not using the digital upconversion mixer (`dac_mode=DacMode.Direct`);
            if `phases_q` is not specified when using the digital upconversion mixer (`dac_mode=DacMode.Mixedxx`).

        See also
        --------
        next_frequency
        select_frequency
        """
        output_ports = np.atleast_1d(output_ports).astype(np.int64)
        if output_ports.min() < 1 or output_ports.max() > self._nr_ports:
            raise ValueError(f"valid output ports are 1-{self._nr_ports}")

        group = int(group)
        if group not in range(2):
            raise ValueError("valid groups are 0-1")

        freq_lut = np.atleast_1d(frequencies).astype(np.float64)
        phase_i_lut = np.atleast_1d(phases).astype(np.float64)

        if len(phase_i_lut) != len(freq_lut):
            raise ValueError("frequency_lut and phase_lut must have the same dimensions")
        if len(freq_lut) > MAX_LUT_ENTRIES:
            raise ValueError(f"frequency_lut can contain at most {MAX_LUT_ENTRIES} elements")
        if np.any(freq_lut >= self.get_fs("dac") / 2) or np.any(freq_lut < 0):
            raise ValueError("Invalid frequency")

        if self.dac_direct:
            if phases_q is not None:
                raise ValueError("`phases_q` can't be specified when the DAC is in Mixed mode")
            phase_q_lut = phase_i_lut + 2 * np.pi * freq_lut / self.get_fs("dac")
        else:
            if phases_q is None:
                raise ValueError("`phases_q` must be specified when the DAC is in Mixed mode")
            phase_q_lut = np.atleast_1d(phases_q).astype(np.float64)
            if len(phase_q_lut) != len(phase_i_lut):
                raise ValueError("`phases` and `phases_q` must have the same dimensions")

        for port in output_ports:
            channel = port - 1
            self.freq_luts[channel][group] = freq_lut.copy()
            self.phase_i_luts[channel][group] = phase_i_lut.copy()
            self.phase_q_luts[channel][group] = phase_q_lut.copy()
            self._freq_axis[channel][group] = axis

    @no_after_run
    def next_frequency(self, at_time, output_ports, group=None):
        r"""Program the hardware to move to the next frequency/phase at given time.

        Parameters
        ----------
        at_time : float
            At what time in seconds the change should happen. Must be a multiple of :meth:`get_clk_T`
        output_ports : int or list of int
            What output ports should be affected by the change. Valid ports are in the interval `[1,`
            :meth:`get_nr_ports`\ `]`.
        group: int, optional
            Valid groups are in the interval `[0, 1]`. If :obj:`None`, move the carrier for both groups to the next
            entry.

        Raises
        ------
        ValueError
            if `at_time` is not a multiple of :meth:`get_clk_T`;
            if any of `output_ports` is out of `[1,` :meth:`get_nr_ports`\ `]`;
            if `group` is out of `[0, 1]`.

        See also
        --------
        setup_freq_lut
        select_frequency
        """
        output_ports = np.atleast_1d(output_ports).astype(np.int64)
        if output_ports.min() < 1 or output_ports.max() > self._nr_ports:
            raise ValueError(f"valid output ports are 1-{self._nr_ports}")
        if group is None:
            group = range(2)
        else:
            group = np.atleast_1d(group).astype(np.int64)
            if group.min() < 0 or group.max() > 1:
                raise ValueError("valid groups are [0, 1]")
        time_clk = self.time_to_clk(at_time)
        for port in output_ports:
            for grp in group:
                self.seq.append([time_clk, NextFreq(channel=port - 1, group=grp)])

    @no_after_run
    def next_scale(self, at_time, output_ports, group=None):
        r"""Program the hardware to move to the next output scale at given time.

        Parameters
        ----------
        at_time : float
            At what time in seconds the change should happen. Must be a multiple of :meth:`get_clk_T`
        output_ports : int or list of int
            What output ports should be affected by the change. Valid ports are in the interval `[1,`
            :meth:`get_nr_ports`\ `]`.
        group: int, optional
            Valid groups are in the interval `[0, 1]`. If :obj:`None`, move both groups to the next entry.

        Raises
        ------
        ValueError
            if `at_time` is not a multiple of :meth:`get_clk_T`;
            if any of `output_ports` is out of `[1,` :meth:`get_nr_ports`\ `]`;
            if `group` is out of `[0, 1]`.

        See also
        --------
        setup_scale_lut
        select_scale
        """
        output_ports = np.atleast_1d(output_ports).astype(np.int64)
        if output_ports.min() < 1 or output_ports.max() > self._nr_ports:
            raise ValueError(f"valid output ports are 1-{self._nr_ports}")
        if group is None:
            group = range(2)
        else:
            group = np.atleast_1d(group).astype(np.int64)
            if group.min() < 0 or group.max() > 1:
                raise ValueError("valid groups are [0, 1]")
        time_clk = self.time_to_clk(at_time)
        for port in output_ports:
            for grp in group:
                self.seq.append([time_clk, NextScale(channel=port - 1, group=grp)])

    @no_after_run
    def reset_phase(self, at_time, output_ports, group=None):
        r"""Program the hardware to reset the phase of `group` at given time.

        The phase will be reset to the current entry of the frequency/phase look-up table.

        Parameters
        ----------
        at_time : float
            at what time in seconds the pulse(s) should be output. Must be a multiple of :meth:`get_clk_T`
        output_ports : int or list of int
            what output ports should be affected by the reset. Valid ports are in the interval `[1,`
            :meth:`get_nr_ports`\ `]`.
        group: int, optional
            valid groups are in the interval `[0, 1]`. If `None`, reset the phase of both groups.

        Raises
        ------
        ValueError
            if `at_time` is not a multiple of :meth:`get_clk_T`;
            if any of `output_ports` is out of `[1,` :meth:`get_nr_ports`\ `]`;
            if `index` is out of `[0,` :const:`MAX_LUT_ENTRIES` `- 1]`;
            if `group` is out of `[0, 1]`.

        See also
        --------
        setup_freq_lut
        next_frequency
        select_frequency
        """
        output_ports = np.atleast_1d(output_ports).astype(np.int64)
        if output_ports.min() < 1 or output_ports.max() > self._nr_ports:
            raise ValueError(f"valid output ports are 1-{self._nr_ports}")
        if group is None:
            group = range(2)
        else:
            group = np.atleast_1d(group).astype(np.int64)
            if group.min() < 0 or group.max() > 1:
                raise ValueError("valid groups are range(2)")
        time_clk = self.time_to_clk(at_time)
        for port in output_ports:
            for grp in group:
                self.seq.append([time_clk, ResetPhase(channel=port - 1, group=grp)])

    @no_after_run
    def select_frequency(self, at_time, index, output_ports, group=None):
        r"""Program the hardware to select a frequency/phase at given time.

        Parameters
        ----------
        at_time : float
            At what time in seconds the change should happen. Must be a multiple of :meth:`get_clk_T`
        index : int
            Zero-based index in look-up table to select. Valid indexes are in the interval `[0,`
            :const:`MAX_LUT_ENTRIES` `- 1]`.
        output_ports : int or list of int
            What output ports should be affected by the change. Valid ports are in the interval `[1,`
            :meth:`get_nr_ports`\ `]`.
        group: int, optional
            Valid groups are in the interval `[0, 1]`. If `None`, select new frequency/phase on both groups.

        Raises
        ------
        ValueError
            if `at_time` is not a multiple of :meth:`get_clk_T`;
            f any of `output_ports` is out of `[1,` :meth:`get_nr_ports`\ `]`;
            if `index` is out of `[0,` :const:`MAX_LUT_ENTRIES` `- 1]`;
            if `group` is out of `[0, 1]`.

        See also
        --------
        setup_freq_lut
        next_frequency
        """
        output_ports = np.atleast_1d(output_ports).astype(np.int64)
        if output_ports.min() < 1 or output_ports.max() > self._nr_ports:
            raise ValueError(f"valid output ports are 1-{self._nr_ports}")

        index = int(index)
        if index < 0 or index >= MAX_LUT_ENTRIES:
            raise ValueError(f"valid look-up table indexes are 0-{MAX_LUT_ENTRIES - 1}")

        if group is None:
            group = range(2)
        else:
            group = np.atleast_1d(group).astype(np.int64)
            if group.min() < 0 or group.max() > 1:
                raise ValueError("valid groups are [0, 1]")

        time_clk = self.time_to_clk(at_time)
        for port in output_ports:
            for grp in group:
                self.seq.append([time_clk, SelFreq(channel=port - 1, group=grp, index=index)])

    @no_after_run
    def select_scale(self, at_time, index, output_ports, group=None):
        r"""Program the hardware to select an output scale at given time.

        Parameters
        ----------
        at_time : float
            At what time in seconds the change should happen. Must be a multiple of :meth:`get_clk_T`
        index : int
            Zero-based index in look-up table to select. Valid indexes are in the interval `[0,`
            :const:`MAX_LUT_ENTRIES` `- 1]`.
        output_ports : int or list of int
            What output ports should be affected by the change. Valid ports are in the interval `[1,`
            :meth:`get_nr_ports`\ `]`.
        group: int, optional
            Valid groups are in the interval `[0, 1]`. If `None`, select new scale on both groups.

        Raises
        ------
        ValueError
            if `at_time` is not a multiple of :meth:`get_clk_T`;
            if any of `output_ports` is out of `[1,` :meth:`get_nr_ports`\ `]`;
            if `index` is out of `[0,` :const:`MAX_LUT_ENTRIES` `- 1]`;
            if `group` is out of `[0, 1]`.

        See also
        --------
        setup_scale_lut
        next_scale
        """
        output_ports = np.atleast_1d(output_ports).astype(np.int64)
        if output_ports.min() < 1 or output_ports.max() > self._nr_ports:
            raise ValueError(f"valid output ports are 1-{self._nr_ports}")

        index = int(index)
        if index < 0 or index >= MAX_LUT_ENTRIES:
            raise ValueError(f"valid look-up table indexes are 0-{MAX_LUT_ENTRIES - 1}")

        if group is None:
            group = range(2)
        else:
            group = np.atleast_1d(group).astype(np.int64)
            if group.min() < 0 or group.max() > 1:
                raise ValueError("valid groups are [1, 2]")

        time_clk = self.time_to_clk(at_time)
        for port in output_ports:
            for grp in group:
                self.seq.append([time_clk, SelScale(channel=port - 1, group=grp, index=index)])

    @no_after_run
    def setup_long_drive(
        self,
        output_port,
        group,
        duration,
        *,
        amplitude=1.0,
        amplitude_q=None,
        rise_time=0.0,
        fall_time=0.0,
        envelope=True,
        output_marker=None,
    ) -> LongDrive:
        r"""Create a long output pulse with constant amplitude.

        Useful for using fewer templates.

        Parameters
        ----------
        output_port : int or list of int
            valid ports are in the interval `[1,` :meth:`get_nr_ports`\ `]`.
        group : int
            the group to use for this pulse, valid group are in the interval `[0, 1]`.
        duration : float
            total length of the pulse in seconds. Must be a multiple of :meth:`get_clk_T`
        amplitude : float or complex, optional
            amplitude of the flat part of the pulse. Should be real when
            `dac_mode` is :class:`DacMode.Direct <DacMode>`, and complex when
            :class:`DacMode.Mixedxx <DacMode>`. Alternatively, use the
            `amplitude_q` parameter.
        amplitude_q : float, optional
            amplitude of the Q quadrature of the flat part of the pulse. Only used when `dac_mode` is one of
            :class:`DacMode.Mixedxx <DacMode>`. Alternatively, use a complex value for the `amplitude` argument.
        rise_time : float, optional
            smoothen the initial `rise_time` seconds of the pulse. Must be a multiple of :meth:`get_clk_T`. See Notes.
        fall_time : float, optional
            smoothen the final `fall_time` seconds of the pulse. Must be a multiple of :meth:`get_clk_T`. See Notes.
        envelope : bool, optional
            If :obj:`True` (default) set up an envelope instead of a template: the envelope will be multiplied by the
            carrier in `group`. If :obj:`False`, set up a template: the template will be output as is. In both cases,
            the resulting waveform will be scaled by the scaler in `group`.
        output_marker : int, optional
            output a high value from digital output number `output_marker` for the duration of the pulse. If
            :obj:`None` (default), no marker is output. Valid ports are in `[1, 4]`.

        Returns
        -------
        long_drive : LongDrive

        Raises
        ------
        RuntimeError
            If there are not enough templates available for the pair `output_port`-`group`.
        ValueError
            if `output_port` is out of `[1,` :meth:`get_nr_ports`\ `]`;
            if `group` is out of `[0, 1]`;
            if `amplitude` is out of `[-1.0, +1.0]`;
            if `duration`, `rise_time` or `fall_time` are invalid.

        Notes
        -----
        A long drive is always used as an envelope, i.e. it's always multiplied by a carrier.

        Regardless of `duration`, only one template is consumed for a flat long drive.

        The amplitude of the pulse is affected by the group scaler configured with :meth:`setup_scale_lut`. The
        parameter `amplitude` is applied "in series".

        When `rise_time` and/or `fall_time` are nonzero, one additional template is used for each rise and fall
        segments. The rise and fall times are subtracted from the flat time, so that the total duration of the pulse
        including transients is `duration`. The rise and fall shapes are :math:`\sin(\frac{\pi}{2}x)^2` and
        :math:`\cos(\frac{\pi}{2}x)^2`, respectively, with :math:`x \in [0, 1)`. For implementation details,
        `rise_time` and `fall_time` are limited to 1022 ns (one template slot each).

        See also
        --------
        setup_template : create a custom template/envelope.
        output_pulse : program hardware to output the generated pulse.
        """
        output_ports = np.atleast_1d(output_port).astype(np.int64)
        if output_ports.min() < 1 or output_ports.max() > self._nr_ports:
            raise ValueError(f"valid output ports are 1-{self._nr_ports}")

        group = int(group)
        if group not in range(2):
            raise ValueError(f"Valid group are 0-1, got {group}")

        envelope = bool(envelope)

        if output_marker is not None:
            output_marker = int(output_marker)
            if output_marker < 1 or output_marker > 4:
                raise ValueError(f"Invalid `output_marker`, expected 1-4, got {output_marker}")

        templates_needed = 1
        if rise_time:
            templates_needed += 1
        if fall_time:
            templates_needed += 1

        # check we have enough templates on all ports
        for output_port in output_ports:
            channel = output_port - 1
            used_templates = self.used_templates[channel][group]
            available_templates = OUT_TMPL_PER_GRP - used_templates
            if templates_needed > available_templates:
                raise RuntimeError(
                    f"Not enough template slots available on"
                    f" output {output_port} group {group}."
                    f" Need {templates_needed}, but {available_templates}"
                    f"/{OUT_TMPL_PER_GRP} are available."
                )

        total_clk = self.time_to_clk(duration)
        rise_clk = self.time_to_clk(rise_time)
        fall_clk = self.time_to_clk(fall_time)
        flat_clk = total_clk - rise_clk - fall_clk

        max_rise_fall_clk = MAX_TEMPLATE_LEN // SMPLS_PER_CLK
        max_rise_fall_time = max_rise_fall_clk * self.get_clk_T()
        if rise_clk > max_rise_fall_clk:
            raise ValueError(
                f"`rise_time` should be no larger than {max_rise_fall_time*1e9:.0f} ns"
            )
        if fall_clk > max_rise_fall_clk:
            raise ValueError(
                f"`fall_time` should be no larger than {max_rise_fall_time*1e9:.0f} ns"
            )
        if rise_clk + fall_clk > total_clk:
            raise ValueError("`rise_time + fall_time` can't be longer than `duration`")

        amplitude = complex(amplitude)
        if self.dac_direct:
            if amplitude.imag != 0.0:
                raise ValueError(
                    f"`amplitude` must be real when DAC is in Direct mode, got {amplitude}"
                )
            if amplitude_q is not None:
                raise ValueError("`amplitude_q` cannot be specified when DAC is in Direct mode")
        else:
            if amplitude_q is not None:
                if amplitude.imag != 0.0:
                    raise ValueError(
                        f"`amplitude`={amplitude} is complex AND `amplitude_q`={amplitude_q} is specified: choose one!"
                    )
                else:
                    amplitude += 1j * float(amplitude_q)

        if (abs(amplitude.real) > 1.0) or (abs(amplitude.imag) > 1.0):
            raise ValueError(f"`amplitude` must be in [-1.0; +1.0], got {amplitude}")

        if rise_clk:
            ns = SMPLS_PER_CLK * rise_clk
            if not self.dac_direct:
                ns //= 2
            x = np.linspace(0.0, 1.0, ns, endpoint=False)
            rise_template = amplitude.real * np.sin(np.pi / 2 * x) ** 2
            if self.dac_direct:
                rise_template_q = None
            else:
                rise_template_q = amplitude.imag * np.sin(np.pi / 2 * x) ** 2
            rise_pulse = self.setup_template(
                output_ports, group, rise_template, rise_template_q, envelope=envelope
            )
            rise_pulse = rise_pulse.get_templates()
        else:
            rise_pulse = []

        if self.dac_direct:
            flat_template = amplitude.real * np.ones(4 * SMPLS_PER_CLK)
            flat_template_q = None
        else:
            flat_template = amplitude.real * np.ones(2 * SMPLS_PER_CLK)
            flat_template_q = amplitude.imag * np.ones(2 * SMPLS_PER_CLK)
        flat_pulse = self.setup_template(
            output_ports, group, flat_template, flat_template_q, envelope=envelope
        )
        flat_pulse = flat_pulse.get_templates()
        for _p in flat_pulse:
            _p.duration = flat_clk
            _p.offset = rise_clk

        if fall_clk:
            ns = SMPLS_PER_CLK * fall_clk
            if not self.dac_direct:
                ns //= 2
            x = np.linspace(0.0, 1.0, ns, endpoint=False)
            fall_template = amplitude.real * np.cos(np.pi / 2 * x) ** 2
            if self.dac_direct:
                fall_template_q = None
            else:
                fall_template_q = amplitude.imag * np.cos(np.pi / 2 * x) ** 2
            fall_pulse = self.setup_template(
                output_ports, group, fall_template, fall_template_q, envelope=envelope
            )
            fall_pulse = fall_pulse.get_templates()
            for _p in fall_pulse:
                _p.offset = rise_clk + flat_clk
        else:
            fall_pulse = []

        long_drive = LongDrive(
            rise=rise_pulse,
            flat=flat_pulse,
            fall=fall_pulse,
            dig_out=output_marker - 1 if output_marker is not None else None,
            pls=weakref.ref(self),
        )

        return long_drive

    @no_after_run
    def setup_template(
        self, output_port, group, template, template_q=None, *, envelope=False, output_marker=None
    ) -> Template:
        r"""Create an output template or envelope.

        Parameters
        ----------
        output_port : int or list of int
            Valid ports are in the interval `[1,` :meth:`get_nr_ports`\ `]`.
        group : int
            The group to use for this pulse, valid group are in the interval `[0, 1]`.
        template : np.ndarray of np.float64
            Data points for the template/envelope with :meth:`get_fs("dac") <get_fs>` sampling rate.
            Valid range is `[-1.0, +1.0]`.
        template_q : np.ndarray of np.float64
            data points for the Q quadrature to the digital upconversion mixer. Must be specified if and only if
            `dac_mode` is one of :class:`DacMode.Mixedxx <DacMode>` (not :class:`DacMode.Direct <DacMode>`).
        envelope : bool, optional
            If :obj:`True` set up an envelope instead of a template: the envelope will be multiplied by the carrier in
            `group`. If :obj:`False` (default), set up a template: the template will be output as is. In both cases,
            the resulting waveform will be scaled by the scaler in `group`.
        output_marker : int, optional
            Output a high value from digital output number `output_marker` for the duration of the pulse. If
            :obj:`None` (default), no marker is output. Valid ports are in `[1, 4]`.

        Returns
        -------
        Template

        Raises
        ------
        RuntimeError
            If there are not enough templates available for the pair `output_port`-`group`.
        ValueError
            If any of `output_port` is out of `[1,` :meth:`get_nr_ports`\ `]`;
            if any sample in `template` is out of `[-1.0, +1.0]`;
            if `group` is out of `[0, 1]`.

        Notes
        -----
        If the length of the pulse is longer than a single template slot (:meth:`get_max_template_len` samples), the pulse
        is automatically split into multiple segments of appropriate length. Therefore, the pulse might use more than
        one template slot.

        See also
        --------
        setup_long_drive : create a long flat pulse using fewer templates.
        output_pulse : program hardware to output the generated template.
        """
        group = int(group)
        if group not in range(2):
            raise ValueError(f"Invalid `group`, expected 0-1, got {group}")

        envelope = bool(envelope)

        output_ports = np.atleast_1d(output_port).astype(np.int64)
        if output_ports.min() < 1 or output_ports.max() > self._nr_ports:
            raise ValueError(f"valid output ports are 1-{self._nr_ports}")
        channels = output_ports - 1

        if output_marker is not None:
            output_marker = int(output_marker)
            if output_marker < 1 or output_marker > 4:
                raise ValueError(f"Invalid `output_marker`, expected 1-4, got {output_marker}")

        # make sure template is a complex np array
        template = np.atleast_1d(template).astype(np.complex128)

        if self.dac_direct:
            if np.any(np.imag(template) != 0.0):
                raise ValueError("`template` must be real when DAC is in Direct mode")
            if template_q is not None:
                raise ValueError("`template_q` cannot be specified when the DAC is in Direct mode")
        else:
            if template_q is not None:
                if np.any(np.imag(template) != 0.0):
                    raise ValueError(
                        "`template` is complex AND `template_q` is specified: choose one!"
                    )
                else:
                    template_q = np.atleast_1d(template_q).astype(np.float64)
                    template.imag = template_q

        if (np.max(np.abs(np.real(template))) > 1.0) or (np.max(np.abs(np.imag(template))) > 1.0):
            raise ValueError("all `template` values must be in [-1.0; +1.0]")

        if self.dac_direct:
            # discard imaginary part
            template = np.real(template)
        else:
            # we represent templates as IQ sequences
            template = np.frombuffer(template, np.float64)  # double the length!

        # template must be a multiple of SMPLS_PER_CLK samples
        if template.shape[0] % SMPLS_PER_CLK > 0:
            template = np.concatenate(
                (template, np.zeros(SMPLS_PER_CLK - template.shape[0] % SMPLS_PER_CLK))
            )

        # load templates and store template trigger information
        ret = Template(
            channels=channels.tolist(),
            group=group,
            envelope=envelope,
            events=[],  # set in the loop below
            pls=weakref.ref(self),
        )
        if output_marker is not None:
            ret.append(
                DigitalOut(
                    channel=output_marker - 1,
                    duration=template.shape[0] // SMPLS_PER_CLK,
                )
            )

        # check that there's enough template slots available
        templates_needed = math.ceil(template.shape[0] / MAX_TEMPLATE_LEN)
        for channel in channels:
            used_templates = self.used_templates[channel][group]
            available_templates = OUT_TMPL_PER_GRP - used_templates
            if templates_needed > available_templates:
                raise RuntimeError(
                    f"Not enough template slots available on"
                    f" output {channel+1} group {group}."
                    f" Need {templates_needed}, but {available_templates}"
                    f"/{OUT_TMPL_PER_GRP} are available."
                )

        offset = 0
        _zeros = [0] * SMPLS_PER_CLK
        while template.shape[0] > 0:
            subtempl_len = min(MAX_TEMPLATE_LEN, template.shape[0])
            for channel in channels:
                if self.used_templates[channel][group] >= OUT_TMPL_PER_GRP:
                    # this should not happen because we check above
                    raise RuntimeError(f"Not enough templates on output {channel+1} group {group}")
                index = self.used_templates[channel][group] + group * OUT_TMPL_PER_GRP
                ret.append(
                    RawTemplate(
                        channel=int(channel),
                        group=int(group),
                        index=int(index),
                        duration=int(subtempl_len // SMPLS_PER_CLK),
                        offset=int(offset),
                        envelope=bool(envelope),
                        inverted=None,  # set by setup_condition
                        pls=weakref.ref(self),
                    )
                )

                self.templates[channel][index] = np.r_[_zeros, template[:subtempl_len]]
                if envelope:
                    self.modulate[channel] |= 1 << index
                self.used_templates[channel][group] += 1
            offset += subtempl_len // SMPLS_PER_CLK
            template = template[subtempl_len:]

        return ret

    @no_after_run
    def setup_template_matching_pair(
        self, input_port, template1, template2=None, threshold=0.0, compare_next_port=False
    ):
        r"""Create a pair of input templates for template matching.

        The result of template matching can be obtained after the measurement with :meth:`get_template_matching_data`.
        The matching also defines a condition that can be used to mask one or more output templates during the
        measurement with :meth:`setup_condition`. The template-matching condition is True if the match with `template1`
        plus the match with `template2` is greater or equal than `threshold`, False otherwise.

        Parameters
        ----------
        input_port : int
            valid ports are in the interval `[1,` :meth:`get_nr_ports`\ `]`. If `compare_next_port=True`, it must be
            odd.
        template1 : numpy.ndarray
        template2 : numpy.ndarray, optional
            data points for the templates with :meth:`get_fs("adc") <get_fs>` sampling rate. Valid range is `[-1.0,
            +1.0]`. If `template2` is not provided, it will be set to all zeros.
            `dtype` is :class:`float` when `adc_mode=AdcMode.Direct` and :class:`complex` when `adc_mode=AdcMode.Mixed` (when using digital downconversion).
        threshold : float, optional
            level for discrimination between a successful and failed comparison. The scale is such that a perfect match
            of a full-scale cosine over `N` data samples `0.5 * N`.

        compare_next_port : bool, optional
            if `True`, match `template1` from `input_port` and `template2` from `input_port+1`. If `False`, match both
            from `input_port`.

        Returns
        -------
        list of :class:`Match`

        Raises
        ------
        RuntimeError
            if there are not enough templates available for `input_port`.
        ValueError
            if `input_port` is out of `[1,` :meth:`get_nr_ports`\ `]`;
            if any sample in the templates is out of `[-1.0, +1.0]`;
            if the templates are longer than :meth:`get_max_template_len`;
            if `abs(threshold)` is bigger than :const:`MAX_THRESHOLD`.
        NotImplementedError
            if the templates have different length.

        Notes
        -----
        To evaluate a match, the input data acquired from port `input_port` is first multiplied with each template
        element-wise, and then summed. If the match using `template1` plus the match using `template2` is greater than
        or equal to `threshold`, the match is considered successful.

        See also
        --------
        setup_condition
        match
        get_template_matching_data
        """
        input_port = int(input_port)
        if input_port < 1 or input_port > self._nr_ports:
            raise ValueError(
                f"Invalid `input_port`, expected 1-{self._nr_ports}, got {input_port}"
            )
        compare_next_port = bool(compare_next_port)
        if compare_next_port and input_port % 2 != 1:
            raise ValueError("With `compare_next_port=True`, `input_port` must be odd.")

        input_index1 = input_port - 1
        if compare_next_port:
            input_index2 = input_index1 + 1
        else:
            input_index2 = input_index1

        # make sure template is a np array
        if self.adc_direct:
            template1 = np.atleast_1d(template1)
            if np.any(template1.imag != 0.0):
                raise ValueError("`template1` must be real when `adc_mode=AdcMode.Direct`")
            template1 = template1.astype(np.float64)
        else:
            template1 = np.atleast_1d(template1).astype(np.complex128)
            template1 = np.frombuffer(template1, np.float64)  # double the length!
        if len(template1) > MAX_TEMPLATE_LEN:
            raise ValueError(f"template too long, max length {MAX_TEMPLATE_LEN:d}")
        if (template1.max() > 1.0) or (template1.min() < -1.0):
            raise ValueError("all template values must be in [-1.0; +1.0]")

        if template2 is None:
            template2 = np.zeros_like(template1)
        else:
            if self.adc_direct:
                template2 = np.atleast_1d(template2)
                if np.any(template2.imag != 0.0):
                    raise ValueError("`template2` must be real when `adc_mode=AdcMode.Direct`")
                template2 = template2.astype(np.float64)
            else:
                template2 = np.atleast_1d(template2).astype(np.complex128)
                template2 = np.frombuffer(template2, np.float64)  # double the length!
            if len(template2) > MAX_TEMPLATE_LEN:
                raise ValueError(f"template too long, max length {MAX_TEMPLATE_LEN:d}")
            if len(template2) != len(template1):
                raise NotImplementedError("templates must have same length")
            if (template2.max() > 1.0) or (template2.min() < -1.0):
                raise ValueError("all template values must be in [-1.0; +1.0]")

        threshold = float(threshold)
        if abs(threshold) > MAX_THRESHOLD:
            raise ValueError(f"Maximum value for `threshold` is {MAX_THRESHOLD}, got {threshold}")

        template_index1 = None
        template_index2 = None
        if compare_next_port:
            for i in range(MATCH_TMPL_PER_GRP):
                if not np.any(self.used_match_templates[input_index1 : input_index2 + 1, i]):
                    template_index1 = i
                    template_index2 = i
                    break
            if template_index1 is None or template_index2 is None:
                raise RuntimeError(
                    f"No available slots for reference templates"
                    f" on inputs {input_port},{input_port + 1}"
                )
        else:
            for i in range(0, MATCH_TMPL_PER_GRP, 2):
                if not np.any(self.used_match_templates[input_index1, i : i + 2]):
                    template_index1 = i
                    template_index2 = i + 1
                    break
            if template_index1 is None or template_index2 is None:
                raise RuntimeError(
                    f"No available slots for reference templates" f" on input {input_port}"
                )
        self.used_match_templates[input_index1, template_index1] = True
        self.used_match_templates[input_index2, template_index2] = True

        _zeros = [0] * SMPLS_PER_CLK
        triginfo = []
        for input_index, template_index, template_data in zip(
            [input_index1, input_index2],
            [template_index1, template_index2],
            [template1, template2],
        ):
            # template must be a multiple of SMPLS_PER_CLK samples
            if template_data.shape[0] % SMPLS_PER_CLK > 0:
                template_data = np.r_[
                    template_data, np.zeros(SMPLS_PER_CLK - template_data.shape[0] % SMPLS_PER_CLK)
                ]

            self.match_templates[input_index][template_index] = np.r_[_zeros, template_data]

            triginfo.append(
                Match(
                    group=input_index,
                    index=template_index,
                    duration=template_data.shape[0] // SMPLS_PER_CLK,
                    threshold=int(round(threshold * _THRESHOLD_SCALE)),
                    cross_group=compare_next_port,
                    pls=weakref.ref(self),
                )
            )

        return triginfo

    @no_after_run
    def match(self, at_time, match_info):
        """Program hardware to perform template matching at given time.

        Parameters
        ----------
        at_time : float
            At what time in seconds the template(s) should be matched. Must be a multiple of :meth:`get_clk_T`
        template_info : Match or list of Match
            The information about one or more template-matching pairs as obtained from
            :meth:`setup_template_matching_pair`.

        Raises
        ------
        ValueError
            if `at_time` is not a multiple of :meth:`get_clk_T`
        TypeError
            if `template_info` contains unrecognized objects.

        See also
        --------
        setup_template_matching_pair
        """
        matches = as_flat_list(match_info)
        time_clk = self.time_to_clk(at_time)
        for match in matches:
            if not isinstance(match, Match):
                raise TypeError("{} is not a valid Match event!".format(match))
            self.seq.append([time_clk, match])

    @no_after_run
    def output_pulse(self, at_time, pulse_info):
        """Program hardware to output pulse(s) at given time.

        Parameters
        ----------
        at_time : float
            at what time in seconds the pulse(s) should be output. Must be a multiple of :meth:`get_clk_T`
        pulse_info : Template, LongDrive or list
            information about one or more pulses as obtained from :meth:`setup_template` or :meth:`setup_long_drive`

        Raises
        ------
        ValueError
            if `at_time` is not a multiple of :meth:`get_clk_T`
        TypeError
            if `pulse_info` contains unrecognized objects
        """
        templates = as_flat_list(pulse_info)
        time_clk = self.time_to_clk(at_time)
        for template in templates:
            if isinstance(template, (Template, LongDrive)):
                for partial_event in template.get_events():
                    self.seq.append([time_clk, partial_event])
            else:
                raise TypeError(f"Not a valid pulse: {template}")

    @no_after_run
    def output_digital_marker(self, at_time, duration, ports):
        """Program hardware to output a digital marker at given time.

        Parameters
        ----------
        at_time : float
            at what time in seconds the marker should be output. Must be a multiple of :meth:`get_clk_T`
        duration : float
            for how long in seconds the marker should be output. Must be a multiple of :meth:`get_clk_T`
        port : int or list of int
            digital output port(s) the marker should be output from. Valid values are in `[1, 4]`

        Raises
        ------
        ValueError
            if `ports` is out of range;
            if `at_time` is not a multiple of :meth:`get_clk_T`
        """
        ports = np.atleast_1d(ports).astype(np.int64)
        if ports.min() < 1 or ports.max() > 4:
            raise ValueError("valid output ports are 1-4")
        time_clk = self.time_to_clk(at_time)
        duration_clk = self.time_to_clk(duration)

        for port in ports:
            dig_out = DigitalOut(
                channel=port - 1,
                duration=duration_clk,
            )
            self.seq.append([time_clk, dig_out])

    @no_after_run
    def output_dc_bias(self, at_time, bias, port):
        """Program hardware to output a DC bias at given time.

        Parameters
        ----------
        at_time : float
            at what time in seconds the bias should be output. Must be a multiple of :meth:`get_clk_T`
        bias : float
            DC bias value in volts.
        port : int
            output port the DC bias should be output from. Valid values are in `[1, 16]`

        Notes
        -----
        For optimal performance, it is not possible to change the DC range
        during an experimental sequence. Only the bias value can be changed. It
        is required to use :meth:`hardware.set_dc_bias
        <presto.hardware.Hardware.set_dc_bias>` to configure the range and the
        initial DC-bias value for `port` **before** programming the
        experimental sequence. It is also recommended to use
        :meth:`hardware.set_dc_bias <presto.hardware.Hardware.set_dc_bias>` to
        reset the value to zero after the experiment terminated, *i.e.* after a
        call to :meth:`run`.

        Raises
        ------
        ValueError
            if `port` is out of range;
            if `at_time` is not a multiple of :meth:`get_clk_T`;
            if `bias` is larger than the current setting for DC-bias range on `port`.
        RuntimeError
            if the DC range for `port` was not set.
        """
        port = int(port)
        if self.hardware.board == "zcu111":
            max_port = 8
        else:
            max_port = 16
        if port < 1 or port > max_port:
            raise ValueError(f"valid output ports are in [1, {max_port}]")

        time_clk = self.time_to_clk(at_time)

        bias = float(bias)
        try:
            (min_bias, max_bias) = self.hardware.last_dc_range(port)
        except KeyError:
            raise RuntimeError(
                f"no current range found for port {port}, "
                "have you run `hardware.set_dc_bias` to set the initial configuration?"
            ) from None
        if bias < min_bias or bias > max_bias:
            raise ValueError(
                f"`bias` {bias} is not within the current DC-bias range [{min_bias:.2f},{max_bias:.2f}]"
            )
        # switch to full-scale units
        bias = bias / max_bias

        if min_bias == 0.0:
            # positive-only range
            bias_code = int(round(bias * 65535))
        else:
            # bipolar range
            ni = int(round(bias * 32767))
            bias_code = ni + 0x8000
        channel = port - 1

        if self.hardware.board == "zcu111":
            raw_command = 1 << 19  # DACx register
            raw_command |= channel << 16
            raw_command |= bias_code
        else:
            raw_command = 0x40_0000  # Write code to and update DAC Channel x
            raw_command |= channel << 16  # Channel x
            raw_command |= bias_code  # code

        dc_bias_out = DcBiasOut(
            channel=port - 1,
            raw_command=raw_command,
        )
        self.seq.append([time_clk, dc_bias_out])

    def get_store_data(self):
        """Obtain from hardware the result of the (averaged) stores.

        Only valid after the measurment is performed.

        Returns
        -------
        t_arr : numpy.ndarray
            The time axis in seconds during one acquisition. `dtype` is :class:`float`.
        data : numpy.ndarray
            The acquired data with :meth:`get_fs("adc") <Pulsed.get_fs>` sample rate and scaled to +/-1.0 being
            full-scale input. The shape of the array is `(num_stores * repeat_count, num_ports, smpls_per_store)`,
            where `num_stores` is number of store events programmed in a sequence with the :meth:`store` method,
            `num_ports` is the number of inputs ports set with :meth:`set_store_ports`, and `smpls_per_store` is the
            number of samples in one acquisition set by :meth:`set_store_duration`.

        Notes
        -----
        When using digital downconversion (`adc_mode=AdcMode.Mixed`), the returned `data` is complex
        (`dtype=np.complex128`); in direct mode (`adc_mode=AdcMode.Direct`) `data` is real (`dtype=np.float64`).

        Raises
        ------
        RuntimeError
            If no store data is available.

        See also
        --------
        store
        run
        """
        if self._avg_data is None:
            raise RuntimeError("No store data available. Have you run a measurement?")

        return self._avg_t_arr, self._avg_data

    def get_template_matching_data(self, input_pairs):
        """Obtain from hardware the result of the template matching.

        Only valid after the measurment is performed.

        Parameters
        ----------
        input_pairs : Match or list of Match
            One or more template-matching pairs as defined by :meth:`setup_template_matching_pair`.

        Returns
        -------
        ret : list
            For each element (input template) of `input_pairs`, `ret` contains a :class:`numpy.ndarray` with the
            template-matching results for that template. Therefore, `len(input_pairs) == len(ret)`. `dtype` is
            :class:`float`. The data is scaled such that a perfect match of a full-scale cosine over `N` data samples
            is `0.5 * N`.

        Raises
        ------
        RuntimeError
            If no template-matching data is available.
        TypeError
            If `input_pairs` contains unrecognized objects.

        See also
        --------
        setup_template_matching_pair
        match
        run
        """
        matches = as_flat_list(input_pairs)

        if self._match_data is None:
            raise RuntimeError(
                "No template-matching data available." + "Have you run a measurement?"
            )

        ret = []
        for match in matches:
            if not isinstance(match, Match):
                raise TypeError("{} is not a valid Match event!".format(match))
            tag = (match.group) + (match.index << 4)
            ret.append(self._match_data[self._match_tags == tag])

        return ret

    def _out_command(self, trigger, scale1, scale2, f1, reset_f1, f2, reset_f2, flags):
        trigger1 = int(trigger) & 0xFF  # 8 bits
        trigger2 = int(trigger >> 8) & 0xFF  # 8 bits
        scale1 = int(scale1) & 0x1FF  # 9 bits
        scale2 = int(scale2) & 0x1FF  # 9 bits
        f1 = int(f1) & 0x1FF  # 9 bits
        reset_f1 = int(reset_f1) & 0x1  # 1 bit
        f2 = int(f2) & 0x1FF  # 9 bits
        reset_f2 = int(reset_f2) & 0x1  # 1 bit
        flags1 = int(flags) & 0xF  # 4 bits
        flags2 = int(flags >> 4) & 0xF  # 4 bits

        command1 = 0
        command1 |= trigger1 << 0
        command1 |= scale1 << 8
        command1 |= f1 << 17
        command1 |= reset_f1 << 26
        command1 |= flags1 << 27

        command2 = 0
        command2 |= trigger2 << 0
        command2 |= scale2 << 8
        command2 |= f2 << 17
        command2 |= reset_f2 << 26
        command2 |= flags2 << 27

        command = command1 | (command2 << 32)

        return command

    def _process_sequence(self, period_clk):
        out_cmds = [[] for _ in range(self._nr_ports)]
        # out_cmd: (time_clk, trigger_or, trigger_and, scale1_idx, scale2_idx, f1_idx, f1_res, f2_idx, f2_res, flags)
        # flags: bits high to low: set_f2, set_scale2, next_f2, next_scale2 __ set_f1, set_scale1, next_f1, next_scale1
        match_cmds = []  # (time_clk, group // 4, index_mask)
        store_cmds = []  # (time_clk, channel_mask)
        digout_cmds = []  # (time_clk, marker_mask_or, marker_mask_and)
        nr_matches = 0
        for (time_clk, entry) in self.seq:
            if isinstance(entry, RawTemplate):
                # index = self.templates[entry.channel][entry.index][1]
                out_cmds[entry.channel].append(
                    (
                        time_clk + entry.offset,
                        1 << entry.index,
                        ~0,
                        -1,
                        -1,
                        -1,
                        0,
                        -1,
                        0,
                        0b0000_0000,
                    )
                )
                out_cmds[entry.channel].append(
                    (
                        time_clk + entry.offset + entry.duration,
                        0,
                        ~(1 << entry.index),
                        -1,
                        -1,
                        -1,
                        0,
                        -1,
                        0,
                        0b0000_0000,
                    )
                )
            elif isinstance(entry, Match):
                block = entry.group // GRPS_PER_CMD
                index = (entry.group % GRPS_PER_CMD) * MATCH_TMPL_PER_GRP + entry.index
                match_cmds.append((time_clk + _STORE_TO_MATCH_LATENCY, block, 1 << index))
                match_cmds.append((time_clk + entry.duration + _STORE_TO_MATCH_LATENCY, block, 0))
                nr_matches += 1
            elif isinstance(entry, Store):
                store_cmds.append((time_clk, 1 << entry.channel))
                store_cmds.append((time_clk + entry.duration, 0))
            elif isinstance(entry, DigitalOut):
                digout_cmds.append((time_clk + _DLY_DIG_OUT, 1 << entry.channel, ~0))
                digout_cmds.append(
                    (time_clk + entry.duration + _DLY_DIG_OUT, 0, ~(1 << entry.channel))
                )
            elif isinstance(entry, DcBiasOut):
                # lower 4 bits are for DigitalOut
                # 24 bits << 4 for DAC raw command
                # bit 24 << 4 for WE
                digout_cmds.append(
                    (time_clk, (entry.raw_command | (1 << 24)) << 4, ~(0x1FF_FFFF << 4))
                )
                # release WE some time later, leave data there
                digout_cmds.append((time_clk + 6, 0, ~(0x100_0000 << 4)))
            elif isinstance(entry, NextFreq):
                if entry.group == 0:
                    out_cmds[entry.channel].append(
                        (time_clk, 0, ~0, -1, -1, -1, 1, -1, 0, 0b0000_0010)
                    )
                elif entry.group == 1:
                    out_cmds[entry.channel].append(
                        (time_clk, 0, ~0, -1, -1, -1, 0, -1, 1, 0b0010_0000)
                    )
                else:
                    raise NotImplementedError
                # release reset the next clock cycle
                out_cmds[entry.channel].append(
                    (time_clk + 1, 0, ~0, -1, -1, -1, 0, -1, 0, 0b0000_0000)
                )
            elif isinstance(entry, NextScale):
                if entry.group == 0:
                    out_cmds[entry.channel].append(
                        (time_clk, 0, ~0, -1, -1, -1, 0, -1, 0, 0b0000_0001)
                    )
                elif entry.group == 1:
                    out_cmds[entry.channel].append(
                        (time_clk, 0, ~0, -1, -1, -1, 0, -1, 0, 0b0001_0000)
                    )
                else:
                    raise NotImplementedError
            elif isinstance(entry, ResetPhase):
                if entry.group == 0:
                    out_cmds[entry.channel].append(
                        (time_clk, 0, ~0, -1, -1, -1, 1, -1, 0, 0b0000_0000)
                    )
                elif entry.group == 1:
                    out_cmds[entry.channel].append(
                        (time_clk, 0, ~0, -1, -1, -1, 0, -1, 1, 0b0000_0000)
                    )
                else:
                    raise NotImplementedError
                # release reset the next clock cycle
                out_cmds[entry.channel].append(
                    (time_clk + 1, 0, ~0, -1, -1, -1, 0, -1, 0, 0b0000_0000)
                )
            elif isinstance(entry, SelFreq):
                if entry.group == 0:
                    out_cmds[entry.channel].append(
                        (time_clk, 0, ~0, -1, -1, entry.index, 1, -1, 0, 0b0000_1000)
                    )
                elif entry.group == 1:
                    out_cmds[entry.channel].append(
                        (time_clk, 0, ~0, -1, -1, -1, 0, entry.index, 1, 0b1000_0000)
                    )
                else:
                    raise NotImplementedError
                # release reset the next clock cycle
                out_cmds[entry.channel].append(
                    (time_clk + 1, 0, ~0, -1, -1, -1, 0, -1, 0, 0b0000_0000)
                )
                _lut = self.freq_luts[entry.channel][entry.group]
                _lut_len = 0 if _lut is None else len(_lut)
                if entry.index >= _lut_len:
                    raise RuntimeError(
                        f"trying to select frequency index {entry.index} on port {entry.channel+1} group {entry.group},"
                        f" but programmed frequency LUT has only {_lut_len} entries."
                    )
            elif isinstance(entry, SelScale):
                if entry.group == 0:
                    out_cmds[entry.channel].append(
                        (time_clk, 0, ~0, entry.index, -1, -1, 0, -1, 0, 0b0000_0100)
                    )
                elif entry.group == 1:
                    out_cmds[entry.channel].append(
                        (time_clk, 0, ~0, -1, entry.index, -1, 0, -1, 0, 0b0100_0000)
                    )
                else:
                    raise NotImplementedError
                _lut = self.scale_luts[entry.channel][entry.group]
                _lut_len = 0 if _lut is None else len(_lut)
                if entry.index >= _lut_len:
                    raise RuntimeError(
                        f"trying to select scale index {entry.index} on port {entry.channel+1} group {entry.group},"
                        f" but programmed scale LUT has only {_lut_len} entries."
                    )
            else:
                raise NotImplementedError

        # Sort and merge out_cmds
        merged_out_cmds = []
        for channel in range(self._nr_ports):
            seq = sorted(out_cmds[channel])
            merged = []
            trigger = 0
            scale1_idx = 0
            scale2_idx = 0
            f1_idx = 0
            f2_idx = 0
            last = [None]
            for entry in seq:
                if entry == last:
                    continue
                (
                    trig_time,
                    trig_or,
                    trig_and,
                    _scale1_idx,
                    _scale2_idx,
                    _f1_idx,
                    _f1_res,
                    _f2_idx,
                    _f2_res,
                    _flags,
                ) = entry

                trigger &= trig_and
                trigger |= trig_or
                if _scale1_idx >= 0:
                    scale1_idx = _scale1_idx
                if _scale2_idx >= 0:
                    scale2_idx = _scale2_idx
                if _f1_idx >= 0:
                    f1_idx = _f1_idx
                if _f2_idx >= 0:
                    f2_idx = _f2_idx
                if last[0] != trig_time:
                    new_entry = [
                        trig_time,
                        channel,
                        trigger,
                        scale1_idx,
                        scale2_idx,
                        f1_idx,
                        _f1_res,
                        f2_idx,
                        _f2_res,
                        _flags,
                    ]
                    merged.append(new_entry)
                else:
                    # merged[-1][0] = trig_time
                    # merged[-1][1] = channel
                    merged[-1][2] = trigger
                    merged[-1][3] = scale1_idx
                    merged[-1][4] = scale2_idx
                    merged[-1][5] = f1_idx
                    merged[-1][6] |= _f1_res
                    merged[-1][7] = f2_idx
                    merged[-1][8] |= _f2_res
                    merged[-1][9] |= _flags
                last = entry
            self._add_dummies(merged, period_clk, True)
            merged_out_cmds.extend(merged)

        # Convert out_cmds
        all_cmds = []  # (time_clk, channel, cmd)
        for (
            time_clk,
            channel,
            trigger,
            scale1_idx,
            scale2_idx,
            f1_idx,
            f1_res,
            f2_idx,
            f2_res,
            flags,
        ) in merged_out_cmds:
            command = self._out_command(
                trigger, scale1_idx, scale2_idx, f1_idx, f1_res, f2_idx, f2_res, flags
            )
            all_cmds.append([time_clk, channel, command])

        # Sort and merge match_cmds
        seq = sorted(match_cmds)
        merged = []
        last = [None, None, None]
        for entry in seq:
            if entry == last:
                continue
            trig_time, trig_block, trig_mask = entry
            channel = trig_block + _CHANNEL_MATCH_BASE
            if last[0] != trig_time:
                merged.append([trig_time, channel, trig_mask])
            elif last[1] != trig_block:
                merged.append([trig_time, channel, trig_mask])
            else:
                merged[-1][2] |= trig_mask
            last = entry
        self._add_dummies(merged, period_clk)
        all_cmds.extend(merged)

        # Sort and merge store_cmds
        seq = sorted(store_cmds)
        merged = []
        last = [None, None]
        channel = _CHANNEL_STORE
        for entry in seq:
            if entry == last:
                continue
            trig_time, trig_mask = entry
            if last[0] != trig_time:
                merged.append([trig_time, channel, trig_mask])
            else:
                merged[-1][2] |= trig_mask
            last = entry
        self._add_dummies(merged, period_clk)
        all_cmds.extend(merged)

        # Sort and merge digout_cmds
        seq = sorted(digout_cmds)
        merged = []
        marker_mask = 0
        last = [None]
        channel = _CHANNEL_DIGOUT
        for entry in seq:
            if entry == last:
                continue
            trig_time, marker_mask_or, marker_mask_and = entry
            marker_mask &= marker_mask_and
            marker_mask |= marker_mask_or
            if last[0] != trig_time:
                merged.append([trig_time, channel, marker_mask])
            else:
                merged[-1][2] = marker_mask
            last = entry
        self._add_dummies(merged, period_clk)
        all_cmds.extend(merged)

        # Sort all_cmds
        all_cmds = sorted(all_cmds)

        return all_cmds, nr_matches

    def _add_dummies(self, seq: list, period_clk: int, is_out_cmd=False):
        if not _ADD_DUMMIES:
            return

        if len(seq) == 0:
            return

        # add first command at the end for next repetition
        seq.append(seq[0].copy())
        seq[-1][0] += period_clk

        for i, _ in enumerate(seq):
            if seq[i][0] - seq[i - 1][0] > _WRAPPING_TIME:
                dummy = seq[i - 1].copy()
                dummy[0] += _WRAPPING_TIME
                if is_out_cmd:
                    # set next/select flags to zero
                    dummy[-1] = 0
                seq.insert(i, dummy)

        # remove last command we added
        seq.pop(-1)
        pass

    @no_after_run
    def setup_condition(self, input_pairs, output_templates_true, output_templates_false=None):
        """Setup a template-matching condition for one or more output pulses.

        The pulses in `output_templates_true` (`output_templates_false`) will be marked as conditional, and will be
        output if and only if all the template-matching conditions defined in `input_pairs` are (not) satisfied.

        Parameters
        ----------
        input_pairs : Match or list of Match
            One or more template-matching pairs as defined by :meth:`setup_template_matching_pair`.
        output_templates_true : Template, LongDrive or list
            Output in case of a successful match comparison.
            One or more pulses as defined by :meth:`setup_template` and/or :meth:`setup_long_drive`.
            Set to :obj:`None` or to an empty list `[]` if no pulse is desired.
        output_templates_false : Template, LongDrive or list, optional
            Output in case of a unsuccessful match comparison.
            One or more pulses as defined by :meth:`setup_template` and/or :meth:`setup_long_drive`.
            Set to :obj:`None` or to an empty list `[]` if no pulse is desired (default).

        See also
        --------
        setup_template_matching_pair
        match
        """
        input_pairs = as_flat_list(input_pairs)

        if output_templates_true is None:
            output_templates_true = []
        if output_templates_false is None:
            output_templates_false = []

        # output_templates will contain both true and false
        output_templates = as_flat_list(output_templates_true)
        for ii, template in enumerate(output_templates):
            if isinstance(template, (Template, LongDrive)):
                output_templates[ii] = template.get_templates()
            else:
                raise TypeError(f"{template} is not a valid template!")
        output_templates = as_flat_list(output_templates)

        output_templates_false = as_flat_list(output_templates_false)
        for ii, template in enumerate(output_templates_false):
            if isinstance(template, (Template, LongDrive)):
                output_templates_false[ii] = template.get_templates()
            else:
                raise TypeError(f"{template} is not a valid template!")
        output_templates_false = as_flat_list(output_templates_false)

        # add false
        output_templates.extend(output_templates_false)

        if self.used_conditioners >= NR_CONDITIONERS:
            raise RuntimeError("No conditioners available")

        conditioner_inputs = 2**64 - 1  # start with all ones (don't look at this comparator)
        comparator_thresholds = list(self.comparator_thresholds)  # make a copy
        comparator_crossport = self.comparator_crossport
        found = 0
        for template in input_pairs:
            if not isinstance(template, Match):
                raise TypeError("Invalid `input_pairs`: {}", template)
            if template.cross_group:
                if template.group % 2 != template.index % 2:
                    # only process even(odd) templates for even(odd) ports as they should come in pairs
                    continue
            else:
                if template.index % 2:
                    # only process even templates as they should come in pairs
                    continue
            index = (template.group * MATCH_TMPL_PER_GRP + template.index) // 2
            conditioner_inputs &= ~(1 << index)  # set bit to zero (look at this comparator)
            if template.cross_group:
                comparator_crossport |= 1 << index
            comparator_thresholds[index] = template.threshold
            found += 1
        if not found:
            raise RuntimeError("This should not happen")

        conditioner_outputs = 0  # start with all zeros (don't control this output template)
        conditional = self.conditional
        conditional_false = self.conditional_false
        found = 0
        for template in output_templates:
            if not isinstance(template, RawTemplate):
                raise TypeError("Invalid `output_templates`: {}", template)

            # Check if we used the template in a conditioner already
            # if so, we check that it's used only as true or only as false
            if template.inverted is None:
                template.inverted = template in output_templates_false
            else:
                if template.inverted != template in output_templates_false:
                    raise NotImplementedError(
                        "This output template was already used in a condition, but with a different polarity (true or"
                        " false). This is not supported. {}",
                        template,
                    )

            index = template.channel * OUT_TMPL_PER_CH + template.index
            conditioner_outputs |= 1 << index  # set bit to one (control this output template)
            conditional += 2**index
            if template in output_templates_false:
                conditional_false += 2**index
            found += 1
        if not found:
            raise ValueError("No template event found in `output_templates`")

        self.conditioner_inputs[self.used_conditioners] = conditioner_inputs
        self.conditioner_outputs[self.used_conditioners] = conditioner_outputs
        self.conditional = conditional
        self.conditional_false = conditional_false
        self.comparator_crossport = comparator_crossport
        self.comparator_thresholds = list(comparator_thresholds)
        self.used_conditioners += 1

    def _check(
        self,
        period_clk,
        repeat_count,
        num_averages,
        print_time,
        verbose,
    ):
        self._status = MeasurementStatus.CHECKING

        t0 = time.time()
        tot_repeats = self._check_repeat_count(repeat_count)
        tot_samples = sum([num for (_, num) in self.saves])
        dma_length = tot_samples * tot_repeats * _BYTES_PER_STORE_SAMPLE
        nr_store_ch = len(self.store_channels)

        if period_clk > _MAX_TIME_OCM_CLK:
            raise ValueError(
                f"chosen `period` {period_clk*self.CLK_T} s is larger"
                f" than maximum supported {_MAX_TIME_OCM_CLK*self.CLK_T} s"
            )

        # Process sequence
        all_cmds, nr_matches = self._process_sequence(period_clk)
        if verbose:
            print(f"\n{' Processed sequence ':-^80}")
            for _cmd in all_cmds:
                print(_cmd)
            print(f"{'':-^80}\n")
        self._check_buffer_overflow(all_cmds, tot_repeats * num_averages, period_clk, verbose)
        self._check_overlapping_stores(all_cmds)
        self._check_dc_bias_rate(all_cmds, period_clk)

        if verbose:
            print(f"dma_length: {dma_length}")
        if dma_length != 0:
            if dma_length < _DMA_MIN:
                raise RuntimeError(
                    f"`dma_length` must be at least {_DMA_MIN}, it was {dma_length}"
                )
            if dma_length % _DMA_MUL != 0:
                raise RuntimeError(
                    f"`dma_length` must be a multiple of {_DMA_MUL}, it was {dma_length}"
                )

        if dma_length == 0 and nr_matches == 0:
            raise NotImplementedError(
                "sequences without any `store` nor `match` are not supported"
            )
        if len(all_cmds) > MAX_COMMANDS:
            raise RuntimeError(
                f"trying to use {len(all_cmds)} commands, maximum is {MAX_COMMANDS}"
            )
        _max_T = all_cmds[-1][0]
        if _max_T > period_clk:
            raise ValueError(
                f"chosen `period` {period_clk*self.CLK_T} s is smaller"
                f" than duration of sequence {_max_T*self.CLK_T} s"
            )

        dma_length_matches = nr_matches * tot_repeats * num_averages * _BYTES_PER_MATCH
        if verbose:
            print(f"dma_length_matches: {dma_length_matches}")
        if dma_length_matches != 0:
            if dma_length_matches < _DMA_MIN:
                raise RuntimeError(
                    f"Not enough `match` events: there must be at least {_DMA_MIN//_BYTES_PER_MATCH},"
                    f" there were {dma_length_matches//_BYTES_PER_MATCH}. Consider adding `match`"
                    " events, or increasing `repeat_count` or `num_averages`."
                )
            if dma_length_matches % _DMA_MUL != 0:
                raise RuntimeError(
                    f"`dma_length_matches` must be a multiple of {_DMA_MUL}, it was {dma_length_matches}"
                )

        # we align the dma for matches at multiples of 4096 bytes
        total_dma_length = dma_length + (dma_length_matches + 4095) // 4096 * 4096
        if verbose:
            print(f"total_dma_length: {total_dma_length}")
        if total_dma_length > _DMA_MAX:
            raise RuntimeError(
                f"requesting too much data: the max total memory size is {_DMA_MAX} bytes,"
                f"requesting {total_dma_length}. Consider removing some `store` or `match` event,"
                " or decreasing `repeat_count` or `num_averages`."
            )

        # check number of commands on each FIFO
        _nr_commands = np.zeros(_NR_FIFOS, int)
        for (_, channel, _) in all_cmds:
            if channel >= _NR_FIFOS:
                channel = channel - _NR_FIFOS
            _nr_commands[channel] += 1
        _max_commands = np.max(_nr_commands)
        _argmax_commands = np.argmax(_nr_commands)
        _avg_fifo_load = _max_commands * _WRAPPING_TIME / period_clk
        if verbose:
            print(f"max commands on FIFO {_argmax_commands}: {_max_commands}")
            print(f"avg_fifo_load: {_avg_fifo_load}")
            print(f"nr commands on OCM: {np.sum(_nr_commands):d}")
        _argmax_commands = np.argmax(_nr_commands)
        if verbose:
            print(f"max commands on FIFO {_argmax_commands}: {_max_commands}")
        # TODO: some sort of check if the RPU and the FIFOs can keep up with the commands

        # check that scale and frequency LUTs have been programmed
        for channel in range(self._nr_ports):
            for group in range(2):
                if self.templates[channel][group * OUT_TMPL_PER_GRP] is not None:
                    if self.scale_luts[channel][group] is None:
                        raise RuntimeError(
                            f"an output template was programmed for port {channel+1} group {group}, but"
                            " the corresponding scale LUT was not set up. Have you called "
                            "setup_scale_lut?"
                        )
                if (self.modulate[channel] >> (group * OUT_TMPL_PER_GRP)) & (
                    2**OUT_TMPL_PER_GRP - 1
                ) > 0:
                    if self.freq_luts[channel][group] is None:
                        raise RuntimeError(
                            f"an output envelope was programmed for port {channel+1} group {group}, but"
                            " the corresponding frequency/phase LUT was not set up. Have you called "
                            "setup_freq_lut?"
                        )

        exp_runtime_clk = period_clk * tot_repeats * num_averages  # clk cycles
        if print_time or verbose:
            t1 = time.time()
            print(f"Measurement sequence processed in {format_sec(t1-t0):s}")
            print(f"Expected measurement time: {format_sec(exp_runtime_clk*self.CLK_T):s}")

        return (
            tot_repeats,
            all_cmds,
            dma_length,
            dma_length_matches,
            nr_matches,
            nr_store_ch,
            exp_runtime_clk,
        )

    def _setup(
        self,
        period_clk,
        tot_repeats,
        num_averages,
        print_time,
        all_cmds,
        dma_length,
        dma_length_matches,
        nr_matches,
        nr_store_ch,
    ):
        self._status = MeasurementStatus.UPLOADING

        if self.dry_run:
            raise RuntimeError("can't call `_setup` when `dry_run=True`")

        t0 = time.time()
        if print_time:
            print("Uploading measurement parameters: ...", end="\r", flush=True)
        # Reset
        self.hardware.set_run(False)

        # upload scale LUT
        for channel in range(self._nr_ports):
            for index in range(2):
                scale_lut = self.scale_luts[channel][index]
                shift_by = self._scale_shifts[channel][index]
                if scale_lut is not None:
                    self.hardware.send_command(
                        cmd.PlsScale,
                        channel,
                        index,
                        len(scale_lut),
                        *scale_lut,
                        shift_by,
                    )

        # upload frequency and phase LUT
        for channel in range(self._nr_ports):
            for index in range(2):
                freq_lut = self.freq_luts[channel][index]
                phase_i_lut = self.phase_i_luts[channel][index]
                phase_q_lut = self.phase_q_luts[channel][index]
                shift_by = self._freq_shifts[channel][index]
                if freq_lut is not None:
                    self.hardware.send_command(
                        cmd.PlsFreqLut,
                        channel,
                        index,
                        len(freq_lut),
                        *freq_lut,
                        shift_by,
                    )
                if phase_i_lut is not None:
                    self.hardware.send_command(
                        cmd.PlsPhaseLutI,
                        channel,
                        index,
                        len(phase_i_lut),
                        *phase_i_lut,
                    )
                if phase_q_lut is not None:
                    self.hardware.send_command(
                        cmd.PlsPhaseLutQ,
                        channel,
                        index,
                        len(phase_q_lut),
                        *phase_q_lut,
                    )

        # upload output templates
        for channel in range(self._nr_ports):
            for index in range(OUT_TMPL_PER_CH):
                entry = self.templates[channel][index]
                if entry is not None:
                    # _, real_idx, template = entry
                    self.hardware.send_command(
                        cmd.PlsOutTmpl,
                        channel,
                        index,
                        len(entry),
                        *entry,
                    )

        # set match multiplexer
        self.hardware.send_command(cmd.PlsMatchMux, 0xFEDCBA9876543210)

        # upload match templates
        for group in range(NR_MATCH_GROUPS):
            for index in range(MATCH_TMPL_PER_GRP):
                template = self.match_templates[group][index]
                if template is not None:
                    self.hardware.send_command(
                        cmd.PlsMatchTmpl,
                        group,
                        index,
                        len(template),
                        *template,
                    )

        # upload modulation
        for channel in range(self._nr_ports):
            self.hardware.send_command(cmd.PlsEnvelope, channel, self.modulate[channel])

        # conditional templates
        self.hardware.send_command(
            cmd.PlsFbDefaultMask,
            (self.conditional >> 0) & (2**64 - 1),
            (self.conditional >> 64) & (2**64 - 1),
            (self.conditional >> 128) & (2**64 - 1),
            (self.conditional >> 192) & (2**64 - 1),
        )
        self.hardware.send_command(
            cmd.PlsFbInvertCondition,
            (self.conditional_false >> 0) & (2**64 - 1),
            (self.conditional_false >> 64) & (2**64 - 1),
            (self.conditional_false >> 128) & (2**64 - 1),
            (self.conditional_false >> 192) & (2**64 - 1),
        )

        # comparators
        self.hardware.send_command(cmd.PlsFbCompareIQ, self.comparator_crossport)
        self.hardware.send_command(cmd.PlsFbCompareConstant, *self.comparator_thresholds)

        # conditioners
        self.hardware.send_command(cmd.PlsFbConditionMask, *self.conditioner_inputs)
        _regs = [0] * (4 * NR_CONDITIONERS)
        for ii in range(NR_CONDITIONERS):
            _regs[4 * ii + 0] = (self.conditioner_outputs[ii] >> 0) & (2**64 - 1)
            _regs[4 * ii + 1] = (self.conditioner_outputs[ii] >> 64) & (2**64 - 1)
            _regs[4 * ii + 2] = (self.conditioner_outputs[ii] >> 128) & (2**64 - 1)
            _regs[4 * ii + 3] = (self.conditioner_outputs[ii] >> 192) & (2**64 - 1)
        self.hardware.send_command(cmd.PlsFbUserMask, *_regs)

        # upload commands
        for (time_clk, channel, command) in all_cmds:
            if channel < 16:
                # output command
                self.hardware.send_command(cmd.PlsOutCmd, time_clk, channel, command)
            elif channel < 32:
                # match
                block = channel - _CHANNEL_MATCH_BASE
                self.hardware.send_command(cmd.PlsMatchCmd, time_clk, block, command)
            elif channel == _CHANNEL_DIGOUT:
                # digital output
                self.hardware.send_command(cmd.PlsDigCmd, time_clk, command)
            elif channel == _CHANNEL_STORE:
                # store command
                self.hardware.send_command(cmd.PlsStoreCmd, time_clk, command)
            else:
                raise RuntimeError(f"unknown channel in OCM commands: {channel}")

        # Start DMAs
        if dma_length > 0:
            self.hardware.start_dma(7, dma_length, nr_cycles=num_averages)  # dma_to_pl
            self.hardware.start_dma(3, dma_length, nr_cycles=num_averages)  # dma_to_ps
        if nr_matches > 0:
            self.hardware.start_dma(2, dma_length_matches, nr_cycles=1, high_mem=True)  # dma_to_ps
        self.hardware.send_command(cmd.PlsStoreMode, nr_store_ch)
        self.hardware.sleep(1e-3, wait=False)

        # Run measurement
        self.hardware.send_command(cmd.PlsNIter, num_averages * tot_repeats, period_clk)
        self.hardware.assert_errors()

        if print_time:
            t1 = time.time()
            print(f"Uploading measurement parameters: {format_sec(t1-t0):s}")

    def _run(
        self,
        tot_repeats,
        num_averages,
        print_time,
        trigger,
        dma_length,
        dma_length_matches,
        nr_matches,
        nr_store_ch,
        exp_runtime_clk,
    ):
        self._status = MeasurementStatus.RUNNING

        if self.dry_run:
            raise RuntimeError("can't call `_setup` when `dry_run=True`")

        self._time_start = datetime.now()
        exp_runtime = timedelta(seconds=exp_runtime_clk * self.CLK_T)
        self._time_end = self._time_start + exp_runtime
        self.hardware.set_run(True, trigger=trigger)

        prev_print_len = 0
        t_last = _T_ZERO
        dma_done = False
        ocm_done = False
        while (not dma_done) and (self._status is not MeasurementStatus.ABORTED):
            t_now = datetime.now()
            (dma_done_avg, dma_err_avg, _) = self.hardware.get_dma_status(3)
            (dma_done_match, dma_err_match, _) = self.hardware.get_dma_status(2)
            dma_done = (dma_done_avg if dma_length > 0 else True) and (
                dma_done_match if nr_matches > 0 else True
            )
            # check using ocm_done from previous loop to give DMA time to transfer
            if ocm_done and (not dma_done):
                eprint_error(
                    "WARNING",
                    "OCM terminated but data transfer is still incomplete",
                    warn=True,
                    inline=True,
                )
            (ocm_done, ocm_err) = self.hardware.get_ocm_status()

            any_error = (ocm_err > 0) or dma_err_avg or dma_err_match
            if any_error:
                msg = []
                msg.append(f"Time since start: {format_sec(t_now - self._time_start)}")
                msg.append(f"Time remaining:   {format_sec(self._time_end - t_now)}")
                msg.append("")
                msg.append(
                    "There was an internal error in the data transfer, data is likely corrupt."
                )
                msg.append(
                    "Aborting measurement, please wait. We'll collect the data measured so far and return."
                )
                msg.append("")
                msg.append("Details:")
                msg.append(f"  dma_err_avg = {dma_err_avg}")
                msg.append(f"  dma_err_match = {dma_err_match}")
                msg.append(f"  ocm_err = {ocm_err}")
                msg = "\n".join(msg)
                print()
                eprint_error("internal error", msg)
                break

            if print_time and (t_now - t_last).total_seconds() > 1.0:
                t_last = t_now
                msg = "Time left: {:s}".format(format_sec(self._time_end - t_now))
                print_len = len(msg)
                if print_len < prev_print_len:
                    msg += " " * (prev_print_len - print_len)
                print("\r" + msg, end="\r", flush=True)
                prev_print_len = print_len
            time.sleep(np.pi / 30)

        if self._status is MeasurementStatus.ABORTED:
            # closing the socket should let conductor abort
            self.close()
            # then raise exception
            raise RuntimeError("measurement aborted by the user")

        self._time_end = datetime.now()
        if print_time:
            print(f"Measurement completed in: {format_sec(self._time_end-self._time_start):s}")
            print("Downloading measurement result: ...", end="\r", flush=True)

        self._status = MeasurementStatus.DOWNLOADING
        # make sure DMA transfers are actually done
        self.hardware.sleep(0.1)

        if dma_length > 0:
            reply = self.hardware.get_dma_data(dma_length)
            dtype = np.dtype(np.int32).newbyteorder("<")
            data = np.frombuffer(reply, dtype=dtype)
            # reshape
            nr_stores = tot_repeats * len(self.saves) // nr_store_ch
            data.shape = (nr_stores, self.store_len // 4, nr_store_ch, 4)
            temp = np.empty((nr_stores, nr_store_ch, self.store_len), dtype=dtype)
            for _iii in range(nr_store_ch):
                temp[:, _iii, :] = np.reshape(data[:, :, _iii, :], (nr_stores, self.store_len))
            # scale to +-1 of input range. NOTE: double the precision int32 --> float64
            data = temp / 32767 / num_averages
            if not self.adc_direct:
                # make data complex without copying
                data = np.frombuffer(data, np.complex128)  # half the length!
                data.shape = (nr_stores, nr_store_ch, self.store_len // 2)
            # create time array
            t_arr = np.arange(data.shape[-1]) / self.get_fs("adc")
            self._avg_data = data
            self._avg_t_arr = t_arr
        if nr_matches > 0:
            reply = self.hardware.get_dma_data(dma_length_matches, high_mem=True)
            dtype = np.dtype(np.int64).newbyteorder("<")
            match_data = np.frombuffer(reply, dtype=dtype)
            self._match_tags = match_data.astype(np.uint16)  # the low 16 bits is the tag
            match_data >>= 16  # remove tag
            self._match_data = match_data.view(np.float64)
            self._match_data[:] = match_data  # convert int64->float64 in place
            self._match_data /= float(_THRESHOLD_SCALE)  # scale

        (_, _, nr_bytes_avg) = self.hardware.get_dma_status(
            3
        )  # previous nr_bytes might not be final
        (_, _, nr_bytes_match) = self.hardware.get_dma_status(
            2
        )  # previous nr_bytes might not be final
        if nr_matches > 0:
            self.hardware.stop_dma(2)
        if dma_length > 0:
            self.hardware.stop_dma(7)
            self.hardware.stop_dma(3)
        self.hardware.set_run(False)

        if print_time:
            t2 = datetime.now()
            print(f"Downloading measurement result: {format_sec(t2-self._time_end):s}")

        self._status = MeasurementStatus.DONE

        # Check for errors
        self.hardware.assert_errors()
        (ocm_done, ocm_err) = self.hardware.get_ocm_status()
        self.hardware.check_adc_intr_status()

        # Print errors
        if dma_length > 0:
            if nr_bytes_avg != dma_length * num_averages:
                eprint_error(
                    "ERROR",
                    f"expected {dma_length * num_averages} DMA transfers (store), got {nr_bytes_avg}",
                    inline=True,
                )
        if nr_matches > 0:
            if nr_bytes_match != dma_length_matches:
                eprint_error(
                    "ERROR",
                    f"expected {dma_length_matches} DMA transfers (match), got {nr_bytes_match}",
                    inline=True,
                )
        if not ocm_done:
            eprint_error("ERROR", "OCM did not terminate", inline=True)
        if ocm_err > 0:
            eprint_error("ERROR", f"OCM encountered an error: {ocm_err:d}", inline=True)

    def perform_measurement(self, *args, **kwargs):
        """
        .. deprecated:: 2.0.0
            Use :meth:`run` instead.
        """
        warnings.warn(
            message="`perform_measurement` is deprecated since version 2.0.0, use `run` instead.",
            category=DeprecationWarning,
            stacklevel=2,
        )
        return self.run(*args, **kwargs)

    def run_async(
        self,
        period,
        repeat_count,
        num_averages,
        print_time=False,
        verbose=False,
        trigger=TriggerSource.Internal,
    ) -> MeasurementHandle:
        """Same as :meth:`run`, but non blocking. See `run` for full documentation."""
        self._status.check_runnable()

        period = float(period)
        num_averages = int(num_averages)
        period_clk = self.time_to_clk(period)

        try:
            (
                tot_repeats,
                all_cmds,
                dma_length,
                dma_length_matches,
                nr_matches,
                nr_store_ch,
                exp_runtime_clk,
            ) = self._check(
                period_clk,
                repeat_count,
                num_averages,
                print_time,
                verbose,
            )

            if not self.dry_run:
                self._setup(
                    period_clk,
                    tot_repeats,
                    num_averages,
                    print_time,
                    all_cmds,
                    dma_length,
                    dma_length_matches,
                    nr_matches,
                    nr_store_ch,
                )

                self.thread = threading.Thread(
                    target=self._run,
                    args=(
                        tot_repeats,
                        num_averages,
                        print_time,
                        trigger,
                        dma_length,
                        dma_length_matches,
                        nr_matches,
                        nr_store_ch,
                        exp_runtime_clk,
                    ),
                )
                self.thread.start()
            else:
                self._status = MeasurementStatus.DONE

            handle = MeasurementHandle(weakref.ref(self))
            return handle
        except (Exception, KeyboardInterrupt):
            self._status = MeasurementStatus.ABORTED
            raise

    def join(self):
        if self.thread is not None:
            self.thread.join()

    def _check_repeat_count(self, repeat_count) -> int:
        allowed_inner_dimensions = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512]

        if isinstance(repeat_count, int):
            tot_repeats = repeat_count

            if not repeat_count > 0:
                raise ValueError(f"`repeat_count` must be positve, got {repeat_count}")

            for j, (axis, shift) in enumerate(zip(self._scale_axis, self._scale_shifts)):
                for i in range(2):  # two groups
                    if axis[i] not in [0, -1]:
                        raise RuntimeError(
                            f"axis on scale LUT port {j+1} group {i} is {axis[i]}, "
                            "but `repeat_count` is an int (no multi-dimensional parameter sweep)"
                        )
                    shift[i] = 0

        elif isinstance(repeat_count, tuple):
            len_rc = len(repeat_count)
            if len_rc == 0:
                raise ValueError("`repeat_count` can't be an empty tuple")
            elif len_rc > 32:
                raise ValueError(
                    f"the maximum number of dimensions is 32, got len(repeat_count) = {len_rc}"
                )

            tot_repeats = 1
            for i, d in enumerate(repeat_count):
                if not isinstance(d, int):
                    raise TypeError(
                        f"`repeat_count` can be an int or a tuple(int), got type tuple({type(d)})"
                    )
                if not d > 0:
                    raise ValueError(f"dimensions must be positve, got {d}")
                if i > 0 and d not in allowed_inner_dimensions:
                    raise ValueError(
                        f"inner dimensions must be a power of 2, got repeat_count[{i}] = {d}"
                    )
                tot_repeats *= d

            shifts = [0]
            for rc in reversed(repeat_count[1:]):
                next_shift = allowed_inner_dimensions.index(rc)
                shifts.append(next_shift + shifts[-1])
            shifts.reverse()

            for j, (axis, shift) in enumerate(zip(self._scale_axis, self._scale_shifts)):
                for i in range(2):  # two groups
                    try:
                        shift[i] = shifts[axis[i]]
                    except IndexError:
                        raise ValueError(
                            f"axis for scale LUT out of range, got {axis[i]} but `repeat_count`"
                            f" only has {len(repeat_count)} dimensions"
                        )
            for j, (axis, shift) in enumerate(zip(self._freq_axis, self._freq_shifts)):
                for i in range(2):  # two groups
                    try:
                        shift[i] = shifts[axis[i]]
                    except IndexError:
                        raise ValueError(
                            f"axis for frequency LUT out of range, got {axis[i]} but `repeat_count`"
                            f" only has {len(repeat_count)} dimensions"
                        )

        else:
            raise TypeError(
                f"`repeat_count` can be an int or a tuple(int), got type {type(repeat_count)}"
            )
        return tot_repeats

    def run(
        self,
        period,
        repeat_count,
        num_averages,
        print_time=True,
        verbose=False,
        trigger=TriggerSource.Internal,
    ):
        """Execute the experiment planned so far. Can be time consuming!

        This method will block until the measurement and the data transfer are completed. See :meth:`run_async` for a
        non-blocking alternative.

        Parameters
        ----------
        period : float
            Measurement time in seconds for one repetition. Should be long enough to include the last event programmed.
            If longer, there will be some waiting time between repetitions. Must be a multiple of :meth:`get_clk_T`
        repeat_count : int or tuple of int
            Number of times to repeat the experiment and stack the acquired data (no averaging). For multi-dimensional
            parameter sweeps, `repeat_count` is a tuple where each element specifies the number of repetitions along
            that axis. All inner axes must have a dimension power of 2, the outermost (index 0) can have any dimension.
            Multi-dimensional parameter sweeps are *experimental* and the API might be fine tuned in a future release.
        num_averages : int
            Number of times to repeat the whole sequence (including the repetitions due to `repeat_count`) and average
            the acquired data.
        print_time : bool, optional
            If :obj:`True`, print to :obj:`standard output <sys.stdout>` the expected runtime before the experiment,
            the total runtime after the experiment, and print during the experiment the estimated time left at regular
            intervals.
        verbose : bool, optional
            If :obj:`True`, print debugging information.
        trigger : TriggerSource, optional
            Select trigger source to start measurement, default internal trigger (start immediately).

        Raises
        ------
        ValueError
            if `period` is negative, too small to fit the last event, or not a multiple of :meth:`get_clk_T`;
            if `repeat_count` is not positive, or if inner dimensions are not power of 2;
            if `num_averages` is not positive.
        RuntimeError
            if the sequence requires more triggers than :const:`MAX_COMMANDS`;
            if more than 8 templates/envelopes are used for the same group on the same port.

        See also
        --------
        get_store_data
        get_template_matching_data

        """
        self._status.check_runnable()

        period = float(period)
        num_averages = int(num_averages)
        period_clk = self.time_to_clk(period)

        try:
            t0 = time.time()
            (
                tot_repeats,
                all_cmds,
                dma_length,
                dma_length_matches,
                nr_matches,
                nr_store_ch,
                exp_runtime_clk,
            ) = self._check(
                period_clk,
                repeat_count,
                num_averages,
                print_time,
                verbose,
            )

            if not self.dry_run:
                self._setup(
                    period_clk,
                    tot_repeats,
                    num_averages,
                    print_time,
                    all_cmds,
                    dma_length,
                    dma_length_matches,
                    nr_matches,
                    nr_store_ch,
                )

                self._run(
                    tot_repeats,
                    num_averages,
                    print_time,
                    trigger,
                    dma_length,
                    dma_length_matches,
                    nr_matches,
                    nr_store_ch,
                    exp_runtime_clk,
                )

            else:
                self._status = MeasurementStatus.DONE

            if print_time:
                t1 = time.time()
                print(f"Total time: {format_sec(t1-t0)}")
        except (Exception, KeyboardInterrupt):
            self._status = MeasurementStatus.ABORTED
            raise

    def _check_buffer_overflow(self, all_cmds, nr_repetitions, period_clk, verbose):
        store_times = np.array(
            [
                time_clk
                for (time_clk, channel, mask) in all_cmds
                if channel == _CHANNEL_STORE and mask != 0
            ]
        )
        if len(store_times) > 0:
            buf_lvl = 0
            prev_time = 0
            fall_rate = AVERAGING_RATE * self.CLK_T  # S/clk_cyc
            nr_store_ch = len(self.store_channels)
            new_store = self.store_len * nr_store_ch
            max_fill = 0
            for time_clk in store_times:
                buf_lvl = max(0, int(np.ceil(buf_lvl - (time_clk - prev_time) * fall_rate)))
                buf_lvl += new_store
                max_fill = max(max_fill, buf_lvl)
                prev_time = time_clk
            residual = max(
                0, int(np.ceil(buf_lvl - (period_clk - prev_time + store_times[0]) * fall_rate))
            )
            max_ever = max_fill + residual * (nr_repetitions - 1)
            if verbose:
                print(f"single rep max store-buffer usage: {max_fill / 1e6} MS")
                print(f"max store-buffer usage: {max_ever / 1e6} MS")
            if max_ever > MAX_STORE_LEN:
                raise RuntimeError(
                    "exceeding maximum `store` rate. Consider decreasing the store duration or"
                    " increasing the time between different store events."
                )

    def _check_overlapping_stores(self, all_cmds):
        in_store = False
        start_time = -1
        for (at_time, channel, mask) in all_cmds:
            if channel != _CHANNEL_STORE:
                continue
            if mask != 0:
                if in_store:
                    # starting a new store while still in a store
                    raise RuntimeError(
                        f"`store` starting at time {round(at_time*self.CLK_T,12)}s overlaps with"
                        f" previous `store` started at time {round(start_time*self.CLK_T,12)}s"
                    )
                else:
                    in_store = True
                    start_time = at_time
            else:
                if not in_store:
                    # stopping a store, but no store was started
                    # raise RuntimeError(
                    #     f"stopping `store` at time {round(at_time*self.CLK_T,12)}s,"
                    #     " but no `store` was started"
                    # )

                    # NOTE: don't raise error here, dummies give false positives
                    # FIXME: add error back when we have dedicated dummy channel
                    pass
                else:
                    in_store = False

    def _check_dc_bias_rate(self, all_cmds, period_clk):
        min_time = self.time_to_clk(1e-6)
        first_time = None
        last_time = None
        last_word = -1
        in_cmd = False
        for (at_time, channel, data) in all_cmds:
            if channel != _CHANNEL_DIGOUT:
                continue
            we = (data >> (24 + 4)) & 1 == 1
            word = (data >> 4) & 0xFF_FFFF
            if in_cmd:
                if we:
                    if word != last_word:
                        raise RuntimeError(
                            "inconsistent sequence of DC-biasing commands."
                            " Make sure commands are spaced by at least 1μs."
                        )
                else:
                    in_cmd = False
            else:
                if we:
                    if last_time is not None:
                        if at_time - last_time < min_time:
                            raise RuntimeError(
                                "exceeding maximum rate for DC-biasing commands."
                                " Make sure commands are spaced by at least 1μs."
                            )
                    else:
                        first_time = at_time
                    last_time = at_time
                    last_word = word
                    in_cmd = True
                else:
                    pass

        if last_time is not None and first_time is not None:
            min_period = last_time - first_time + min_time
            if period_clk < min_period:
                raise RuntimeError(
                    "exceeding maximum rate for DC-biasing commands:"
                    " Make sure commands are spaced by at least 1μs by increasing the period to"
                    f" at least {round(min_period*self.CLK_T,12)} seconds."
                )


class Event:
    """Container for hardware events.

    *The user doesn't need to instantiate this class or its derivatives in any common situation.*

    This is the base class of the return types of many methods of :class:`Pulsed`.
    """

    def __repr__(self) -> str:
        d = dict(self.__dict__)  # make a copy
        keys = sorted(d.keys())
        ll = []
        for key in keys:
            if key.startswith("_"):
                continue
            if isinstance(d[key], float):
                ll.append(f"{key:s} {d[key]:.2e}")
            else:
                ll.append(f"{key:s} {d[key]}")
        rest = ", ".join(ll)
        ret = f"({type(self).__name__}: {rest:s})"
        return ret

    def copy(self):
        """Return a :func:`shallow copy <python:copy.copy>` of this object.

        Returns
        -------
        Event
        """
        return copy.copy(self)


class RawTemplate(Event):
    def __init__(self, channel, group, index, duration, offset, envelope, inverted, pls):
        self.channel = channel
        self.group = group
        self.index = index
        self.duration = duration
        self.offset = offset
        self.envelope = envelope
        self.inverted = inverted
        self._pls = pls

    def get_data(self):
        """Return the underlying data array for in-place modification.

        Returns
        -------
        np.ndarray of np.float64
        """
        return self._pls().templates[self.channel][self.index]


class Template(Event):
    """An output pulse event.

    *The user doesn't need to instantiate this class in any common situation.*

    Return type of :meth:`setup_template <Pulsed.setup_template>`; input type of :meth:`output_pulse
    <Pulsed.output_pulse>`.
    """

    def __init__(
        self,
        channels: List[int],
        group: int,
        envelope: bool,
        events: List[Event],
        pls: ReferenceType[Pulsed],
    ):
        self.channels = channels
        self.group = group
        self.envelope = envelope
        self._events = events
        self._pls = pls

        self.duration = self._get_duration_clk()

    def pls(self) -> Pulsed:
        pls = self._pls()
        if pls is None:
            raise RuntimeError("the associated `Pulsed` object has been destroyed!")
        else:
            return pls

    def append(self, evt: Event):
        self._events.append(evt)
        self.duration = self._get_duration_clk()

    def get_events(self) -> List[Event]:
        return self._events

    def get_templates(self) -> List[RawTemplate]:
        return [x for x in self.get_events() if isinstance(x, RawTemplate)]

    def _get_duration_clk(self) -> int:
        d_clk = 0
        for t in self.get_templates():
            d_t = t.offset + t.duration
            d_clk = max(d_clk, d_t)
        return d_clk

    def get_duration(self) -> float:
        """Get the duration of the template in seconds.

        Returns
        -------
        float
        """
        return self._get_duration_clk() * self.pls().CLK_T


class LongDrive:
    """Container for a long drive.

    *The user doesn't need to instantiate this class in any common situation.*

    Return type of :meth:`setup_long_drive <Pulsed.setup_long_drive>`; input type of :meth:`output_pulse
    <Pulsed.output_pulse>`.
    """

    def __init__(
        self,
        rise: List[RawTemplate],
        flat: List[RawTemplate],
        fall: List[RawTemplate],
        dig_out: Optional[int],
        pls: ReferenceType[Pulsed],
    ):
        self.rise = rise
        self.flat = flat
        self.fall = fall
        self._dig_out = dig_out
        self._pls = pls

    def pls(self) -> Pulsed:
        pls = self._pls()
        if pls is None:
            raise RuntimeError("the associated `Pulsed` object has been destroyed!")
        else:
            return pls

    def get_events(self) -> List[Event]:
        templates: List[Event] = []
        templates.extend(self.get_templates())
        if self._dig_out is not None:
            templates.append(
                DigitalOut(
                    channel=self._dig_out,
                    duration=self._get_total_clk(),
                )
            )
        return templates

    def get_templates(self) -> List[RawTemplate]:
        """Return a list of the individual templates that make up the long drive.

        Returns
        -------
        list of :class:`RawTemplate`
        """
        templates = []
        templates.extend(self.rise)
        templates.extend(self.flat)
        templates.extend(self.fall)
        return templates

    def __repr__(self) -> str:
        return (
            f"(LongDrive: channel {self._get_channels()}, flat {self._get_flat_clk():d}, rise "
            f"{self._get_rise_clk():d}, fall {self._get_fall_clk():d})"
        )

    def _get_channels(self) -> List[int]:
        return [x.channel for x in self.flat]

    def _get_rise_clk(self) -> int:
        if self.rise:
            return self.rise[0].duration
        else:
            return 0

    def _get_flat_clk(self) -> int:
        if self.flat:
            return self.flat[0].duration
        else:
            return 0

    def _get_fall_clk(self) -> int:
        if self.fall:
            return self.fall[0].duration
        else:
            return 0

    def _get_total_clk(self) -> int:
        return self._get_rise_clk() + self._get_flat_clk() + self._get_fall_clk()

    def get_duration(self) -> float:
        """Get the duration of the pulse in seconds.

        Includes rise and fall segments. Same as :meth:`get_total_duration`.

        Returns
        -------
        float

        See also
        --------
        get_total_duration
        get_flat_duration
        """
        return self.get_total_duration()

    def get_total_duration(self) -> float:
        """Total duration of the pulse in seconds.

        Includes rise and fall segments. Same as :meth:`get_duration`.

        Returns
        -------
        float

        See also
        --------
        get_duration
        get_flat_duration
        """
        total_clk = self._get_total_clk()
        return total_clk * self.pls().CLK_T

    def set_total_duration(self, new_duration: float):
        """Update the pulse by changing the total duration of the pulse.

        Rise and fall times are not affected. The new duration of the flat part will be ``new_duration - rise_time -
        fall_time``.

        Parameters
        ----------
        new_duration : float
            New total duration in seconds of the long pulse. Must be a multiple of :meth:`Pulsed.get_clk_T`

        Raises
        ------
        ValueError
            if `new_duration` is not valid.
        """
        new_total_clk = self.pls().time_to_clk(new_duration)
        rise_clk = self._get_rise_clk()
        fall_clk = self._get_fall_clk()
        new_flat_clk = new_total_clk - rise_clk - fall_clk
        if new_flat_clk < 0:
            min_dur_ns = (rise_clk + fall_clk) * self.pls().CLK_T * 1e9
            raise ValueError(f"Minimum duration: rise_time + fall_time = {min_dur_ns:d} ns.")
        self._set_flat_clk(new_flat_clk)

    def get_flat_duration(self) -> float:
        """Duration of the flat segment of the pulse in seconds.

        Does not include rise and fall segments.

        Returns
        -------
        float

        See also
        --------
        get_duration
        get_total_duration
        """
        return self._get_flat_clk() * self.pls().CLK_T

    def set_flat_duration(self, new_duration: float):
        """Update the pulse by changing the duration of the flat part.

        Rise and fall times are not affected. The new total duration will be ``new_duration + rise_time + fall_time``.

        Parameters
        ----------
        new_duration : float
            New duration in seconds for the flat part of the long pulse. Must be a multiple of :meth:`Pulsed.get_clk_T`

        Raises
        ------
        ValueError
            if `new_duration` is not valid.
        """
        new_flat_clk = self.pls().time_to_clk(new_duration)
        if new_flat_clk < 0:
            raise ValueError("can't set negative duration")
        self._set_flat_clk(new_flat_clk)

    def _set_flat_clk(self, new_flat_clk: int):
        self.rise = [x.copy() for x in self.rise]

        self.flat = [x.copy() for x in self.flat]
        for x in self.flat:
            x.duration = new_flat_clk

        self.fall = [x.copy() for x in self.fall]
        for x in self.fall:
            x.offset = new_flat_clk + self._get_rise_clk()


class Match(Event):
    """A template-matching event.

    *The user doesn't need to instantiate this class in any common situation.*

    Return type of :meth:`setup_template_matching_pair <Pulsed.setup_template_matching_pair>`; input type of
    :meth:`match <Pulsed.match>`, :meth:`get_template_matching_data <Pulsed.get_template_matching_data>` and
    :meth:`setup_condition <Pulsed.setup_condition>`.
    """

    def __init__(
        self,
        group: int,
        index: int,
        duration: int,
        threshold: int,
        cross_group: bool,
        pls: ReferenceType[Pulsed],
    ):
        self.group: int = group
        self.index: int = index
        self.duration: int = duration
        self.threshold: int = threshold
        self.cross_group: bool = cross_group
        self._pls: ReferenceType[Pulsed] = pls

    def pls(self) -> Pulsed:
        pls = self._pls()
        if pls is None:
            raise RuntimeError("the associated `Pulsed` object has been destroyed!")
        else:
            return pls

    def get_duration(self) -> float:
        """Get the duration of the match in seconds.

        Returns
        -------
        float
        """
        return self.duration * self.pls().CLK_T


class NextFreq(Event):
    """A next-frequency event, internal use only."""

    def __init__(self, channel: int, group: int):
        self.channel: int = channel
        self.group: int = group


class NextScale(Event):
    """A next-scale event, internal use only."""

    def __init__(self, channel: int, group: int):
        self.channel: int = channel
        self.group: int = group


class ResetPhase(Event):
    """A reset-phase event, internal use only."""

    def __init__(self, channel: int, group: int):
        self.channel: int = channel
        self.group: int = group


class SelFreq(Event):
    """A select-frequency event, internal use only."""

    def __init__(self, channel: int, group: int, index: int):
        self.channel: int = channel
        self.group: int = group
        self.index: int = index


class SelScale(Event):
    """A select-scale event, internal use only."""

    def __init__(self, channel: int, group: int, index: int):
        self.channel: int = channel
        self.group: int = group
        self.index: int = index


class Store(Event):
    """A store event, internal use only."""

    def __init__(self, channel: int, duration: int):
        self.channel: int = channel
        self.duration: int = duration


class DigitalOut(Event):
    """An output marker event, internal use only."""

    def __init__(self, channel: int, duration: int):
        self.channel: int = channel
        self.duration: int = duration


class DcBiasOut(Event):
    """A DC bias output event, internal use only."""

    def __init__(self, channel: int, raw_command: int):
        self.channel: int = channel
        self.raw_command: int = raw_command


class MeasurementStatus(enum.Enum):
    """Enumeration for current status of the measurement"""

    IDLE = enum.auto()  #: standby
    CHECKING = enum.auto()  #: checking user parameters for errors
    UPLOADING = enum.auto()  #: uploading user parameters to the hardware
    ARMED = enum.auto()  #: waiting for trigger
    RUNNING = enum.auto()  #: measurement is running
    DOWNLOADING = enum.auto()  #: measurement is done, downloading measurement data
    DONE = enum.auto()  #: measurement complete
    ABORTED = enum.auto()  #: measurement aborted by the user or by an error

    def runnable(self) -> bool:
        return self in (
            MeasurementStatus.IDLE,
            MeasurementStatus.DONE,
            MeasurementStatus.ABORTED,
        )

    def check_runnable(self):
        if not self.runnable():
            raise RuntimeError("can't run a new measurement while one is already running")


class MeasurementHandle:
    """Handle to a running measurement.

    Return type of :meth:`run_async <Pulsed.run_async>`, *do not instantiate this class directly*.
    """

    def __init__(self, pls: weakref.ReferenceType[Pulsed]):
        self._pls = pls

    def pls(self) -> Pulsed:
        pls = self._pls()
        if pls is None:
            raise RuntimeError("the associated `Pulsed` object has been destroyed!")
        else:
            return pls

    def time_remaining(self) -> timedelta:
        """Estimated remaining time until the end of the measurement.

        Notes
        -----
        If the measurement is not :obj:`RUNNING <MeasurementStatus.RUNNING>`, returns
        `timedelta(0)`.

        Examples
        --------

        >>> tr = handle.time_remaining()
        >>> tr
        datetime.timedelta(seconds=115, microseconds=897831)
        >>> tr.total_seconds()
        115.897831
        >>> str(tr)
        '0:01:55.897831'
        >>> print(tr)
        0:01:55.897831
        >>> from presto.utils import format_sec
        >>> format_sec(tr)
        '1m 55.9s'
        """
        pls = self.pls()
        if pls._status is MeasurementStatus.RUNNING:
            now = datetime.now()
            return pls._time_end - now
        else:
            return timedelta(0)

    def time_elapsed(self) -> timedelta:
        """Time elapsed since the start of the measurement.

        Notes
        -----
        The time elapsed keeps counting even if the measurement is completed.
        When `dry_run=True`, returns `timedelta(0)`.

        Examples
        --------

        >>> te = handle.time_elapsed()
        >>> te
        datetime.timedelta(seconds=269, microseconds=455817)
        >>> te.total_seconds()
        269.455817
        >>> str(te)
        '0:04:29.455817'
        >>> print(te)
        0:04:29.455817
        >>> from presto.utils import format_sec
        '4m 29.5s'
        """
        now = datetime.now()
        time_start = self.pls()._time_start
        if time_start is _T_ZERO:
            return timedelta(0)
        else:
            return now - time_start

    def time_start(self) -> datetime:
        """Start time of the measurement.

        Notes
        -----
        When `dry_run=True`, returns `datetime.fromtimestamp(0)`.

        Examples
        --------

        >>> ts = handle.time_start()
        >>> ts
        datetime.datetime(2022, 6, 22, 14, 52, 53, 850711)
        >>> ts.isoformat()
        '2022-06-22T14:52:53.850711'
        >>> ts.strftime('%Y-%m-%d %H:%M:%S')
        '2022-06-22 14:52:53'
        >>> str(ts)
        '2022-06-22 14:52:53.850711'
        >>> print(ts)
        2022-06-22 14:52:53.850711
        """
        return self.pls()._time_start

    def time_end(self) -> datetime:
        """Estimated end time of the measurement.

        Notes
        -----
        If the measurement is completed, returns the actual time of completion.
        When `dry_run=True`, returns `datetime.fromtimestamp(0)`.

        Examples
        --------

        >>> te = handle.time_end()
        >>> te
        datetime.datetime(2022, 6, 22, 14, 55, 2, 978135)
        >>> te.isoformat()
        '2022-06-22T14:55:02.978135'
        >>> te.strftime('%Y-%m-%d %H:%M:%S')
        '2022-06-22 14:55:02'
        >>> str(te)
        '2022-06-22 14:55:02.978135'
        >>> print(te)
        2022-06-22 14:55:02.978135
        """
        return self.pls()._time_end

    def join(self):
        """Block execution until the measurement is done."""
        return self.pls().join()

    def abort(self):
        """Abort current measurement."""
        self.pls()._status = MeasurementStatus.ABORTED

    def status(self) -> MeasurementStatus:
        """Current status of the measurement"""
        return self.pls()._status
