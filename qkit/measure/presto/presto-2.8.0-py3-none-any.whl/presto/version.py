# Copyright (C) Intermodulation Products AB, 2018 - All Rights Reserved.
# Unauthorized copying of this file, via any medium is strictly prohibited.
# Proprietary and confidential. Please refer to file LICENSE for details.
"""
Under-the-hood version information.

**For all common purposes, the user doesn't need this information**, use the `presto.__version__` constant instead.

Examples
--------
>>> import presto
>>> print(presto.__version__)
2.0.0
>>> print(presto.version.version_api)
2.0.0
>>> presto.__version__ is presto.version.version_api
True
"""
version_api: str = "2.8.0"  # semver string
"""version of the Python public API"""
version_conductor: str = "0.4.4"  # semver string
"""version of the Rust server"""
version_fpga: int = 33  # int
"""version of the firmware for the programmable logic"""
version_rpu: str = "0.4.0"  # semver string
"""version of the firmware for the realtime-processing unit"""


def get_version_api():
    return version_api
