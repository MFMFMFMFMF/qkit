import socket
import sys

ADDRESS = "127.0.0.1"
PORT = 20001
IMAGE_NAME = "send_pulses.png"
COORD_X = 1732
COORD_Y = 402
BUFFER_SIZE = 1024


def _connect():
    sock = socket.socket(family=socket.AF_INET, type=socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_TCP, socket.TCP_NODELAY, 1)
    sock.connect((ADDRESS, PORT))
    return sock


def _click_image(button_name):
    sock = _connect()
    sock.sendall(str.encode("click;image;{}".format(button_name)))
    msg_from_server = sock.recv(BUFFER_SIZE)
    sock.close()
    return msg_from_server.decode("utf-8")


def _click_coordinate(x, y):
    sock = _connect()
    sock.sendall(str.encode("click;coord;{};{}".format(x, y)))
    msg_from_server = sock.recv(BUFFER_SIZE)
    sock.close()
    return msg_from_server.decode("utf-8")


def trigger(use_coord=True):
    if use_coord:
        reply = _click_coordinate(COORD_X, COORD_Y)
    else:
        reply = _click_image(IMAGE_NAME)
    return reply


def quit():
    sock = _connect()
    sock.sendall(str.encode("quit"))
    msg_from_server = sock.recv(BUFFER_SIZE)
    sock.close()
    return msg_from_server.decode("utf-8")


if __name__ == "__main__":
    if len(sys.argv) == 1:
        print(quit())
    elif len(sys.argv) == 2:
        print(_click_image(sys.argv[1]))
    elif len(sys.argv) == 3:
        print(_click_coordinate(int(sys.argv[1]), int(sys.argv[2])))
